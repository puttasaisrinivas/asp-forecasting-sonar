import os
import sys
from datetime import datetime
import pytest
import pandas as pd
import mlflow
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))
from src.train import forecast_asp
from src.utils.helpers import get_config_from_file, read_data,get_config
from src.utils import constants
from config import ConfigDetails
from src.extract import data_process
from src.processing.process import create_train_test_month_quarters
from src.models.arima import train_and_predict_with_arima
from src.utils.track import MLFlowManager
from unittest import mock
from pyspark.sql import SparkSession
from src.processing.post_processing import post_process

@pytest.fixture
def train_predict():
    """ Creates a logger instance"""
    
    # Determine the path to unit_test.yaml relative to this script
    config_path = os.path.join(os.path.dirname(__file__), "../src/configs/unit_test.yaml")
    
    config = get_config_from_file(config_path)
    
    main_logger = mock.MagicMock()
    mlflow_obj = mock.MagicMock()
    catalog_name = mock.MagicMock()
    run_id = mock.MagicMock()
    data_dict_read = read_data(config, catalog_name, main_logger)
    config_obj = ConfigDetails(data_dict_read)

    """ filter the master data and asp data to latest 23 quarters and get the forecast_start_month based on max month of asp actuals"""
    # read the master_data and asp_data input tables
    master_data= config_obj.master_data
    asp_data= config_obj.asp_data 
    # convert the cal_dt to datetime format
    master_data['CAL_DT'] = pd.to_datetime(master_data['CAL_DT'], errors='coerce')
    # Filter the master data with latest 23 quarters
    # 15 quarters are considered for training and latest 8 quarters are considered for test/validation.
    max_date = master_data["CAL_DT"].max()
    start_date = max_date - pd.offsets.QuarterBegin(23)
    training_month_start = start_date + pd.DateOffset(months=1)
    master_data = master_data[(master_data['CAL_DT'] >= training_month_start)]
    asp_data['CAL_DT'] = pd.to_datetime(asp_data['CAL_DT'], errors='coerce')
    asp_data = asp_data[(asp_data['CAL_DT'] >= training_month_start)]
    training_month_end = max_date - pd.offsets.QuarterEnd(8)
    forecast_month_start = training_month_end + pd.DateOffset(months=1)
    forecast_month_start = forecast_month_start.strftime('%Y-%m')
    main_logger.info(f"forecast month:{forecast_month_start}")

    (
        master_data_processed,
        ep_data_processed,
        market_event_data_processed,
        actual_asp_monthly,
        actual_asp_quarterly,
    ) = data_process(config, config_obj, main_logger, master_data, asp_data, forecast_month_start)

    config_dict_generic = get_config(
        config = config,
        generic_flag=True,
        forecast_months=config_obj.forecast_months,
    )
    config_dict_non_generic = get_config(
        config = config,
        generic_flag=False,
        forecast_months=config_obj.forecast_months,
    )

    config_dict_generic.update(config)
    config_dict_non_generic.update(config)
    (
        train_months,
        test_months,
        train_quarters,
        test_quarters,
    ) = create_train_test_month_quarters(
        start_forecast_month=forecast_month_start,
        forecast_months=config_obj.forecast_months,
        processed_master_data=master_data_processed,
        logger=main_logger,
    )
    forecast_month_end = pd.to_datetime(
        forecast_month_start
    ) + pd.DateOffset(months=config_obj.forecast_months - 1)

    # Process generic products
    master_data_processed_generic = master_data_processed[
        master_data_processed["J_CODE"].isin(
            master_data_processed[master_data_processed["PROD_SGMNT"] == "GENERICS"][
                "J_CODE"
            ].unique()
        )
    ]
    master_data_processed_generic = master_data_processed_generic[
        master_data_processed_generic["ASP_MTH"] <= forecast_month_end
    ]

    arima_predicted_data_generic = train_and_predict_with_arima(
        processed_master_data=master_data_processed_generic,
        forecast_months=config_dict_generic["forecast_months"],
        target_variable=config_dict_generic["target_variable"],
        time_series_columns=config_dict_generic["time_series_columns"],
        logger=main_logger,
    )

    model_records = mock.MagicMock()
    registry_records = mock.MagicMock()
    data_drift_records = mock.MagicMock()
    predictions_generic, champion_version = forecast_asp(
        master_data_processed=master_data_processed_generic,
        market_event_data_processed=market_event_data_processed,
        operation_mode='retraining',
        model_alias=None,
        config=config,
        config_dict=config_dict_generic,
        test_months=test_months,
        train_quarters=train_quarters,
        generic_flag=True,
        mlflow_obj=mlflow_obj,
        categorical_cols = config["MODEL_FEATURES"]['GENERIC_PRODUCT']['CATEGORICAL_COLUMNS'],
        model_records = model_records,
        registry_records = registry_records,
        data_drift_records = None,
        catalog_name = catalog_name,
        run_id = run_id,
        logger=main_logger,
    )

    if config_dict_non_generic["forecast_for_priotized_products_only"]:
        master_data_processed_non_generic = master_data_processed[
            master_data_processed["J_CODE"].isin(config_obj.lst_prioritized_jcodes)
        ]
    else:
        master_data_processed_non_generic = master_data_processed

    master_data_processed_non_generic = master_data_processed_non_generic[
        master_data_processed_non_generic["ASP_MTH"] <= forecast_month_end
    ]

    arima_predicted_data_non_generic = train_and_predict_with_arima(
        processed_master_data=master_data_processed_non_generic,
        forecast_months=config_dict_non_generic["forecast_months"],
        target_variable=config_dict_non_generic["target_variable"],
        time_series_columns=config_dict_non_generic["time_series_columns"],
        logger=main_logger,
    )

    # Train and predict the ASP using ARIMA & XGB models for generics products.
    predictions_non_generic, champion_version = forecast_asp(
        master_data_processed=master_data_processed_non_generic,
        market_event_data_processed=market_event_data_processed,
        operation_mode='retraining',
        model_alias=None,
        config=config,
        config_dict=config_dict_non_generic,
        test_months=test_months,
        train_quarters=train_quarters,
        generic_flag=False,
        mlflow_obj=mlflow_obj,
        categorical_cols = config["MODEL_FEATURES"]['NON_GENERIC_PRODUCT']['CATEGORICAL_COLUMNS'],
        model_records = model_records,
        registry_records = registry_records,
        data_drift_records = None,
        catalog_name = catalog_name,
        run_id = run_id,
        logger=main_logger,
    )

    if config_dict_non_generic["forecast_for_priotized_products_only"]:
        predictions_generic = predictions_generic[
            predictions_generic["J_CODE"].isin(config_obj.lst_prioritized_jcodes)
        ]

    predictions_non_generic = predictions_non_generic[
        ~predictions_non_generic["J_CODE"].isin(predictions_generic["J_CODE"].unique())
    ]
    predictions_all = pd.concat([predictions_generic, predictions_non_generic], axis=0)
    test_quarters_to_report = list(set(test_quarters) - set(train_quarters))

    predictions_all["QUARTER"] = predictions_all["QUARTER"].astype(str)
    predictions_all = predictions_all[
        predictions_all["QUARTER"].isin(test_quarters_to_report)
    ]
    lst_prioritized_jcodes = config_obj.lst_prioritized_jcodes

    market_event_data_processed["ASP_MTH"] = (
        pd.to_datetime(market_event_data_processed["ASP_MTH"])
        .dt.strftime("%m/%d/%Y")
        .astype(str)
    )
    market_event_data_processed_generic = market_event_data_processed[
        market_event_data_processed["J_CODE"].isin(
            master_data_processed_generic["J_CODE"].unique()
        )
    ]
    predictions_post_processed = post_process(
        df_actual_train_val=actual_asp_quarterly,
        df_model_forecast=predictions_all,
        df_market_event=market_event_data_processed_generic,
        logger=main_logger,
    )
    
    yield(
        arima_predicted_data_generic,
        arima_predicted_data_non_generic,
        predictions_generic,
        predictions_non_generic,
        predictions_all,
        lst_prioritized_jcodes,
        predictions_post_processed
    )


def test_predictions(train_predict):
    arima_predicted_data_generic, arima_predicted_data_non_generic, predictions_generic, predictions_non_generic, predictions_all, lst_prioritized_jcodes,predictions_post_processed = train_predict
    is_month_level_generic = arima_predicted_data_generic['ASP_MTH'].dt.is_month_start.all()
    is_month_level_non_generic = arima_predicted_data_non_generic['ASP_MTH'].dt.is_month_start.all()
    num_distinct_codes = predictions_all['J_CODE'].nunique()
    num_prioritized_codes = len(lst_prioritized_jcodes)

    assert is_month_level_generic == True, 'ARIMA predicted data for generic is not at month level'
    assert is_month_level_non_generic == True, 'ARIMA predicted data for non generic is not at month level'
    assert num_distinct_codes== num_prioritized_codes, f'Number of distinct codes are not {num_prioritized_codes}, got only {num_distinct_codes}'
    count_data = predictions_post_processed.shape[0]
    num_predictions = len(lst_prioritized_jcodes)*8
    print('count_data:',count_data)
    assert count_data == num_predictions, f'Expected number of records are {num_predictions} but got only {count_data}'






