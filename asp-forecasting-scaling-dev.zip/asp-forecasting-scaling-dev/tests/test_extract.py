import logging
import os
import sys
import pandas as pd
from datetime import datetime
import pytest
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))
from src.utils.logger import setup_logger
from src.utils import constants
from src.utils.helpers import get_config_from_file, read_data
from src.config import ConfigDetails
from src.extract import data_process
from unittest import mock

@pytest.fixture
def extract():
    """
    Creates a logger instance.
    """
    # Determine the path to unit_test.yaml relative to this script
    config_path = os.path.join(os.path.dirname(__file__), "../src/configs/unit_test.yaml")
    
    config = get_config_from_file(config_path)

    logger= mock.MagicMock()
    catalog_name= mock.MagicMock()
    data_dict_read = read_data(config, catalog_name, logger)
    config_obj = ConfigDetails(data_dict_read)
    """ filter the master data and asp data to latest 23 quarters and get the forecast_start_month based on max month of asp actuals"""
    # read the master_data and asp_data input tables
    master_data= config_obj.master_data
    asp_data= config_obj.asp_data 
    # convert the cal_dt to datetime format
    master_data['CAL_DT'] = pd.to_datetime(master_data['CAL_DT'], errors='coerce')
    asp_data['CAL_DT'] = pd.to_datetime(asp_data['CAL_DT'], errors='coerce')
    # Filter the master data with latest 23 quarters
    # 15 quarters are considered for training and latest 8 quarters are considered for test/validation.
    max_date = master_data["CAL_DT"].max()
    start_date = max_date - pd.offsets.QuarterBegin(23)
    training_month_start = start_date + pd.DateOffset(months=1)
    master_data = master_data[(master_data['CAL_DT'] >= training_month_start)]
    asp_data = asp_data[(asp_data['CAL_DT'] >= training_month_start)]
    training_month_end = max_date - pd.offsets.QuarterEnd(8)
    forecast_month_start = training_month_end + pd.DateOffset(months=1)
    forecast_month_start = forecast_month_start.strftime('%Y-%m')

    
    (
        master_data_processed,
        ep_data_processed,
        market_event_data_processed,
        actual_asp_monthly,
        actual_asp_quarterly,
    ) = data_process(config, config_obj, logger, master_data, asp_data, forecast_month_start)

    yield (
        master_data_processed,
        ep_data_processed,
        market_event_data_processed,
        actual_asp_monthly,
        actual_asp_quarterly,
    )


def test_dataprocessing(extract):
    master_data, ep_data, market_event, actual_asp, _ = extract
    assert isinstance(master_data, pd.DataFrame), "Type of Master data is not matching"
    assert isinstance(ep_data, pd.DataFrame), "Type of EP data is not matching"
    assert isinstance(
        market_event, pd.DataFrame
    ), "Type of Market Event is not matching"
    assert isinstance(actual_asp, pd.DataFrame), "Type of Actual ASP is not matching"


def required_columns_check(extract):
    master_data, ep_data, market_event, actual_asp, _ = extract
    market_event_columns = [
        "J_CODE",
        "ASP_MTH",
        "TIME_SINCE_LAST_COMP_LAUNCH",
        "TIME_TO_NEXT_COMP_LAUNCH",
        "TIME_SINCE_LAST_LOE",
        "TIME_TO_NEXT_LOE",
        "TIME_SINCE_SAME_CLASS_LAUNCH"
    ]
    assert (
        market_event.columns.tolist() == market_event_columns
    ), "Required columns are not present in the dataframe"
    return ""


def test_asp_quarterly(extract):
    master_data, ep_data, market_event, actual_asp, _ = extract
    # Check if the 'quarter' column exists
    assert (
        "QUARTER" in actual_asp.columns
    ), "The 'quarter' column does not exist in the data"
    # Check if values in the 'quarter' column follow the quarterly format (YYYYQ#)
    quarters = actual_asp["QUARTER"].unique()
    for quarter in quarters:
        assert (
            len(str(quarter)) == 6
        ), (
            f"Invalid quarter format found: {quarter}"
        )  # Check if the length is 6 characters
        year = quarter.year  # Access the year attribute of the Period object
        quarter_str = (
            quarter.quarter
        )  # Access the quarter attribute of the Period object
        assert (
           1 <= int(quarter_str) <= 4
        ), (
            f"Invalid quarter value found: {quarter}"
        )  # Check if the quarter part is composed of digits between 1 and 4
