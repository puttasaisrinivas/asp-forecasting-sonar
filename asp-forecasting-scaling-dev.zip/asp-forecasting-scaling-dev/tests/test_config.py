import logging
import os
import sys
from datetime import datetime
import pytest
sys.path.insert(0, os.path.abspath(os.path.join(os.path.dirname(__file__), '../src')))
from src.utils import constants
from src.utils.helpers import get_config_from_file, read_data
from src.config import ConfigDetails
from pathlib import Path
from unittest import mock
from pyspark.sql import SparkSession

@pytest.fixture
def config_test():
    """
    Creates a logger instance.
    """

    # Determine the path to unit_test.yaml relative to this script
    config_path = os.path.join(os.path.dirname(__file__), "../src/configs/unit_test.yaml")
    
    config = get_config_from_file(config_path)
    logger = mock.MagicMock()
    catalog_name = mock.MagicMock()
    data_dict_read = read_data(config, catalog_name, logger)
    config_obj = ConfigDetails(data_dict_read)
    yield config_obj

@pytest.mark.filterwarnings("ignore::DeprecationWarning")
def test_configuration(config_test):
    config = config_test
    assert (
        config.master_data is not None
    ), "Master Dataframe is not identified in the Configuration object"
    assert (
        config.asp_data is not None
    ), "ASP Dataframe is not identified in the Configuration object"
    assert (
        config.ep_data is not None
    ), "EP Dataframe is not identified in the Configuration object"
    assert (
        config.forecast_months is not None
    ), "Forecast Months is not identified in the Configuration object"
    assert (
        config.lst_available_jcodes is not None
    ), "Available JCodes are not identified in the Configuration object"
    assert (
        config.lst_prioritized_jcodes is not None
    ), "Proritized JCodes are not identified in the Configuration object"