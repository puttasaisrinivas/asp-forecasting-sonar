import warnings

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import pyspark.pandas as ps
from datetime import datetime, timedelta

from tqdm import tqdm

tqdm.pandas()
from pmdarima.arima import auto_arima

from sklearn.preprocessing import StandardScaler
from xgboost import XGBRegressor
from utils import *
from post_processing import *


class ASPForecaster:
    """
    Class for performing ASP forecasting.

    Args:
        config_excel_path (str): Path to the Excel file containing all data directories.
    """

    def __init__(self, config_excel_path):
        self.config_excel_path = config_excel_path

    def run(self):
        """
        Execute the ASP forecasting process.

        Returns:
            pd.DataFrame: Post-processed ASP forecast predictions.
        """
        # Load data from config Excel file
        print("Beginning to load the data..")
        data_dict_read = read_data(
            path_config=self.config_excel_path, name_index="File Name"
        )
        print("Loaded the data successfully!")
        print("===========================================")

        # Extract parameters from loaded data
        self.forecast_month_start = data_dict_read["forecast_month_start"]
        self.forecast_months = data_dict_read["forecast_months"]
        lst_prioritized_jcodes = list(
            data_dict_read["lst_prioritized_products"]["J_CODE"].unique()
        )
        lst_available_jcodes = list(
            data_dict_read["lst_selected_products"]["J_CODE"].unique()
        )

        # Process data
        print("Processing the loaded data...")
        ep_data_processed = process_ep_data(
            data_dict_read["ep_data"],
            data_dict_read["asp_data"],
            start_date=self.forecast_month_start,
            forecast_months=self.forecast_months,
        )
        market_event_data_processed = process_market_event_features(ep_data_processed)

        master_data_processed = process_master_data(
            data_dict_read["master_data"], market_event_data_processed
        )
        master_data_processed = master_data_processed[
            master_data_processed["J_CODE"].isin(lst_available_jcodes)
        ]
        market_event_data_processed = market_event_data_processed[
            market_event_data_processed["J_CODE"].isin(lst_available_jcodes)
        ]

        actual_asp_monthly = master_data_processed[
            master_data_processed["J_CODE"].isin(lst_available_jcodes)
        ][["J_CODE", "Month", "ASP_true"]].reset_index(drop=True)
        
        actual_asp_monthly["Quarter"] = actual_asp_monthly["Month"].dt.to_period("Q")
        actual_asp_quarterly = (
            actual_asp_monthly.groupby(["J_CODE", "Quarter"])
            .agg({"ASP_true": "first"})
            .reset_index()
        )

        print("Processed the data successfully!")
        print("===========================================")

        # Get configuration dictionaries
        config_dict_generic = get_config(
            generic_flag=True,
            forecast_month_start=self.forecast_month_start,
            forecast_months=self.forecast_months,
        )
        config_dict_non_generic = get_config(
            generic_flag=False,
            forecast_month_start=self.forecast_month_start,
            forecast_months=self.forecast_months,
        )

        # Create train/test months and quarters
        (
            train_months,
            test_months,
            train_quarters,
            test_quarters,
        ) = create_train_test_month_quarters(
            start_forecast_month=self.forecast_month_start,
            forecast_months=self.forecast_months,
            processed_master_data=master_data_processed,
        )
        forecast_month_end = pd.to_datetime(self.forecast_month_start) + pd.DateOffset(
            months=self.forecast_months - 1
        )

        # Process generic products
        master_data_processed_generic = master_data_processed[
            master_data_processed["J_CODE"].isin(
                master_data_processed[master_data_processed["GNRC_IND"] == "Y"][
                    "J_CODE"
                ].unique()
            )
        ]
        master_data_processed_generic = master_data_processed_generic[
            master_data_processed_generic["Month"] <= forecast_month_end
        ]

        print("Training the models and predicting the forecast...")
        print("===========================================")
        print("Forecast for generic products begins...")

        predictions_generic = forecast_asp(
            master_data_processed=master_data_processed_generic,
            market_event_data_processed=market_event_data_processed,
            config_dict=config_dict_generic,
            test_months=test_months,
            train_quarters=train_quarters,
            generic_flag=True,
        )

        print("Forecast for generic products is done successfully!")
        print("===========================================")

        # Process non-generic products
        print("Forecast for Non-generic products begins...")

        if config_dict_non_generic["forecast_for_priotized_products_only"]:
            master_data_processed_non_generic = master_data_processed[
                master_data_processed["J_CODE"].isin(lst_prioritized_jcodes)
            ]
        else:
            master_data_processed_non_generic = master_data_processed

        master_data_processed_non_generic = master_data_processed_non_generic[
            master_data_processed_non_generic["Month"] <= forecast_month_end
        ]
        predictions_non_generic = forecast_asp(
            master_data_processed=master_data_processed_non_generic,
            market_event_data_processed=market_event_data_processed,
            config_dict=config_dict_non_generic,
            test_months=test_months,
            train_quarters=train_quarters,
            generic_flag=False,
        )

        print("Forecast for Non-generic products is done successfully!")

        # Filter and combine predictions
        if config_dict_non_generic["forecast_for_priotized_products_only"]:
            predictions_generic = predictions_generic[
                predictions_generic["J_CODE"].isin(lst_prioritized_jcodes)
            ]

        predictions_non_generic = predictions_non_generic[
            ~predictions_non_generic["J_CODE"].isin(
                predictions_generic["J_CODE"].unique()
            )
        ]
        predictions_all = pd.concat(
            [predictions_generic, predictions_non_generic], axis=0
        )
        test_quarters_to_report = list(set(test_quarters) - set(train_quarters))

        predictions_all["Quarter"] = predictions_all["Quarter"].astype(str)
        predictions_all = predictions_all[
            predictions_all["Quarter"].isin(test_quarters_to_report)
        ]

        # Post-processing
        print("Post processing the predictions...")

        market_event_data_processed["Month"] = (
            pd.to_datetime(market_event_data_processed["Month"])
            .dt.strftime("%m/%d/%Y")
            .astype(str)
        )
        market_event_data_processed_generic = market_event_data_processed[
            market_event_data_processed["J_CODE"].isin(
                master_data_processed_generic["J_CODE"].unique()
            )
        ]
        predictions_post_processed = post_process(
            df_actual_train_val=actual_asp_quarterly,
            df_model_forecast=predictions_all,
            df_market_event=market_event_data_processed_generic,
        )

        print("Post processing successfully done!")

        return predictions_post_processed
