# Databricks notebook source
!pip install xgboost
!pip install pmdarima
!pip install tqdm

# COMMAND ----------

from forecast_asp import *
from datetime import *
import sys

# COMMAND ----------

def main(config_excel_path):
    # config_excel_path = sys.argv[1]
        
    forecaster = ASPForecaster(config_excel_path)
    predictions = forecaster.run()

    filename = "asp_forecast_" +  datetime.now().strftime("%Y%m%d_%H%M%S")+".csv"

    print("===========================================")
    print("Saving the output..")

    predictions.to_csv('../output_data/'+filename,index=False)
    
    print("Saved the output to given directory!")
     
    return predictions
    
# if __name__ == "__main__":
#     main()

# COMMAND ----------

config_excel_path = "../config/config.csv"
predictions = main(config_excel_path)

# COMMAND ----------


