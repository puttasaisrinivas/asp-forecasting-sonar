from forecast_asp import *
import sys
import datetime


def main():
    config_excel_path = "C:\Users\evvm3my\Downloads\asp-forecasting 1\asp-forecasting\config\config.csv"

    forecaster = ASPForecaster(config_excel_path)
    predictions = forecaster.run()

    filename = (
        "asp_forecast_" + datetime.datetime.now().strftime("%Y%m%d_%H%M%S") + ".csv"
    )

    print("===========================================")
    print("Saving the output..")

    predictions.to_csv("../output_data/" + filename, index=False)

    print("Saved the output to given directory!")


if __name__ == "__main__":
    main()
