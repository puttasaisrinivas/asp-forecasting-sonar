import pandas as pd
import numpy as np
from datetime import datetime


def impute_negative_forecast(df_model_forecast, df_actual_train_val):
    """
    Impute negative forecast values in the dataframe based on certain rules.

    Args:
        df_model_forecast (pandas.DataFrame): DataFrame containing forecasted values.
        df_actual_train_val (pandas.DataFrame): DataFrame containing actual values used for imputation.

    Returns:
        pandas.DataFrame: DataFrame with imputed negative forecast values.
    """

    # List of columns to check for negative forecast values
    col_list = ["ASP_pred_unscaled", "ASP_pred_scaled"]

    # Loop through each column in the list
    for impute_column in col_list:
        # Find rows with negative forecast values
        neg_preds = df_model_forecast[df_model_forecast[impute_column] < 0]

        if len(neg_preds) > 0:
            # If negative forecast values exist, sort the dataframe
            df_model_forecast.sort_values(by=["J_CODE", "Quarter"], inplace=True)

            # Replace negative values with the previous non-negative value within each group
            df_model_forecast[impute_column] = df_model_forecast.groupby("J_CODE")[
                impute_column
            ].apply(lambda x: x.where(x.gt(0)).ffill(downcast="int"))

        # Check for groups with all null forecast values
        null_forecast_groups = df_model_forecast.groupby("J_CODE")[impute_column].apply(
            lambda x: x.isnull().all()
        )
        jcodes_with_all_null_forecasts = null_forecast_groups[
            null_forecast_groups
        ].index.tolist()

        # If there are groups with all null forecasts
        if len(jcodes_with_all_null_forecasts) > 0:
            # Separate dataframe into two: one with non-null forecasts and one with all null forecasts
            df_model_forecast_without_nulls = df_model_forecast[
                ~df_model_forecast["J_CODE"].isin(jcodes_with_all_null_forecasts)
            ]
            df_model_forecast_with_nulls = df_model_forecast[
                df_model_forecast["J_CODE"].isin(jcodes_with_all_null_forecasts)
            ]
            new_df_without_nulls = pd.DataFrame(
                columns=list(df_model_forecast_without_nulls.columns)
            )

            # Iterate over groups with all null forecasts
            for jcode in jcodes_with_all_null_forecasts:
                # Get actual values for the group
                jcode_df = df_actual_train_val[df_actual_train_val["J_CODE"] == jcode]
                sorted_df = jcode_df.sort_values(by="Quarter", ascending=False)

                # Replace all null forecast values with the latest actual value for the group
                jcode_forecast_df = df_model_forecast_with_nulls[
                    df_model_forecast_with_nulls["J_CODE"] == jcode
                ]
                # Get the latest actual value
                latest_asp_value = (
                    sorted_df["ASP_true"].dropna().iloc[0]
                    if not sorted_df["ASP_true"].isnull().all()
                    else None
                )
                jcode_forecast_df[impute_column] = latest_asp_value

                # Append the imputed forecasts to the new dataframe
                new_df_without_nulls = new_df_without_nulls.append(
                    jcode_forecast_df, ignore_index=True
                )

            # Combine dataframes with non-null and imputed forecasts
            df_model_forecast = pd.concat(
                [df_model_forecast_without_nulls, new_df_without_nulls], axis=0
            )

    return df_model_forecast


def identify_jcodes_constant_forecast(
    df_actual_train_val, df_model_forecast, train_qrtr, forecast_qrtr
):
    """
    Identify J_CODES with constant forecast for 8 quarters and first quarter forecast same as last quarter actual.

    Args:
        df_actual_train_val (pandas.DataFrame): DataFrame containing actual training/validation data.
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.
        train_qrtr (list): List of training/validation quarters.
        forecast_qrtr (list): List of forecast quarters.

    Returns:
        list: List of J_CODES with constant 8-quarter forecast and first quarter forecast same as last quarter actual.
    """

    # Extracting last quarter actual and first quarter forecast
    df_actual_lastQ = df_actual_train_val.pivot(
        index="J_CODE", columns="Quarter", values="ASP_true"
    )[[train_qrtr[-1]]]
    df_model_forecast_firstQ = df_model_forecast.pivot(
        index="J_CODE", columns="Quarter", values="ASP_Pred"
    )[[forecast_qrtr[0]]]

    # Merging dataframes
    df_actual_lastQ_forecast_firstQ = df_actual_lastQ.join(df_model_forecast_firstQ)
    del df_actual_lastQ, df_model_forecast_firstQ

    # Identify J_CODES with constant 8-quarter forecast
    J_CODE_constant_forecast = (
        df_model_forecast.groupby("J_CODE")["ASP_Pred"]
        .nunique()[
            (df_model_forecast.groupby("J_CODE")["ASP_Pred"].nunique() == 1).values
        ]
        .index
    )

    # Identify J_CODES with first quarter forecast same as last quarter actual
    df_actual_lastQ_forecast_firstQ_SAME = df_actual_lastQ_forecast_firstQ[
        df_actual_lastQ_forecast_firstQ[train_qrtr[-1]]
        == df_actual_lastQ_forecast_firstQ[forecast_qrtr[0]]
    ]

    # Intersect the J_CODES
    df_last_actual_copied = df_actual_lastQ_forecast_firstQ_SAME[
        df_actual_lastQ_forecast_firstQ_SAME.index.isin(J_CODE_constant_forecast)
    ]
    del J_CODE_constant_forecast, df_actual_lastQ_forecast_firstQ_SAME

    # Extract the J_CODES
    j_lastQ_actual_copied = list(df_last_actual_copied.index)

    return j_lastQ_actual_copied


def identify_jcodes_with_highdrop(df_model_forecast, forecast_qrtr):
    """
    Identify J_CODES with a significant drop (more than 20%) in forecast.

    Args:
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.
        forecast_qrtr (list): List of forecast quarters.

    Returns:
        list: List of J_CODES with a significant drop in forecast.
    """
    # Pivot the forecast dataframe
    df_model_forecast_pivot = df_model_forecast.pivot(
        index="J_CODE", columns="Quarter", values="ASP_Pred"
    )

    # Calculate the growth of forecast over the 8 quarters
    df_model_forecast_pivot["growth_of_forecast"] = (
        df_model_forecast_pivot[forecast_qrtr[-1]]
        / df_model_forecast_pivot[forecast_qrtr[0]]
    ) ** (1 / 8)

    # Identify J_CODES with more than 20% drop in forecast
    j_high_drop = list(
        df_model_forecast_pivot[
            df_model_forecast_pivot["growth_of_forecast"] < 0.8
        ].index
    )

    return j_high_drop


def define_start_end_point(
    df_actual_train_val,
    df_model_forecast,
    j_lastQ_actual_copied,
    j_high_drop,
    train_qrtr,
    forecast_qrtr,
):
    """
    Define start and end points for forecasting based on copied actuals and high drop forecasts.

    Args:
        df_actual_train_val (pandas.DataFrame): DataFrame containing actual training/validation data.
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.
        j_lastQ_actual_copied (list): List of J_CODES with last quarter actuals copied.
        j_high_drop (list): List of J_CODES with high drop forecasts.
        train_qrtr (list): List of training/validation quarters.
        forecast_qrtr (list): List of forecast quarters.

    Returns:
        pandas.DataFrame: DataFrame containing start and end points for forecasting.
    """

    # Calculate growth of last quarter actuals
    df_lastQ_growth_actual = df_actual_train_val.pivot(
        index="J_CODE", columns="Quarter", values="ASP_true"
    ).loc[j_lastQ_actual_copied, [train_qrtr[-2], train_qrtr[-1]]]
    df_lastQ_growth_actual = (
        df_lastQ_growth_actual[train_qrtr[-1]] / df_lastQ_growth_actual[train_qrtr[-2]]
    )

    # Calculate end point for J_CODES with last quarter actuals copied
    df_end_point_lastQ_actual_copied = (
        df_actual_train_val.pivot(index="J_CODE", columns="Quarter", values="ASP_true")
        .loc[j_lastQ_actual_copied, [train_qrtr[-1]]]
        .join(df_lastQ_growth_actual.to_frame())
    )
    df_end_point_lastQ_actual_copied = (
        df_end_point_lastQ_actual_copied[train_qrtr[-1]]
        * df_end_point_lastQ_actual_copied[0]
    )

    # Extract end point for J_CODES with high drop forecasts
    df_end_point_high_drop = df_model_forecast.pivot(
        index="J_CODE", columns="Quarter", values="ASP_Pred"
    ).loc[j_high_drop][forecast_qrtr[-1]]

    # Concatenate end points
    df_end_all = pd.concat([df_end_point_lastQ_actual_copied, df_end_point_high_drop])

    # Extract start points for all J_CODES
    df_start_all = df_actual_train_val.pivot(
        index="J_CODE", columns="Quarter", values="ASP_true"
    ).loc[j_lastQ_actual_copied + j_high_drop][train_qrtr[-1]]

    # Concatenate start and end points
    df_start_end_all = df_start_all.to_frame().join(df_end_all.to_frame())
    df_start_end_all.columns = [train_qrtr[-1], forecast_qrtr[-1]]

    return df_start_end_all


def impute_constant_drop(
    df_start_end_all,
    df_model_forecast,
    j_lastQ_actual_copied,
    j_high_drop,
    train_qrtr,
    forecast_qrtr,
):
    """
    Impute constant drop in forecasts using geometric and linear growth.

    Args:
        df_start_end_all (pandas.DataFrame): DataFrame containing start and end points for forecasting.
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.
        j_lastQ_actual_copied (list): List of J_CODES with last quarter actuals copied.
        j_high_drop (list): List of J_CODES with high drop forecasts.
        train_qrtr (list): List of training/validation quarters.
        forecast_qrtr (list): List of forecast quarters.

    Returns:
        pandas.DataFrame: DataFrame containing imputed forecasts.
    """

    # Calculate growth rates
    df_start_end_all["r"] = (
        df_start_end_all[forecast_qrtr[-1]] / df_start_end_all[train_qrtr[-1]]
    ) ** (1 / 8)
    df_start_end_all["beta"] = (
        df_start_end_all[forecast_qrtr[-1]] - df_start_end_all[train_qrtr[-1]]
    ) / 8

    # Linear imputation
    df_imputed_linear = pd.DataFrame(
        index=df_start_end_all.index, columns=forecast_qrtr
    )
    for q in range(len(df_imputed_linear.columns)):
        df_imputed_linear[df_imputed_linear.columns[q]] = (
            df_start_end_all[train_qrtr[-1]] + q * df_start_end_all["beta"]
        )

    # Geometric imputation
    df_imputed_geo = pd.DataFrame(index=df_start_end_all.index, columns=forecast_qrtr)
    for q in range(len(df_imputed_geo.columns)):
        df_imputed_geo[df_imputed_geo.columns[q]] = df_start_end_all[train_qrtr[-1]] * (
            (df_start_end_all["r"]) ** (q + 1)
        )

    # Model forecast
    df_model_forecast_actual = df_model_forecast.pivot(
        index="J_CODE", columns="Quarter", values="ASP_Pred"
    ).loc[df_start_end_all.index]

    # Average imputation for J_CODES with high drop forecasts
    df_imputed = (df_imputed_linear + df_imputed_geo + df_model_forecast_actual) / 3
    df_imputed_j_high_drop = df_imputed.loc[j_high_drop]

    # Average imputation for J_CODES with last quarter actuals copied
    df_imputed = (df_imputed_linear + df_imputed_geo) / 2
    df_imputed_j_lastQ_actual_copied = df_imputed.loc[j_lastQ_actual_copied]

    # Concatenate imputed dataframes
    df_imputed = pd.concat([df_imputed_j_lastQ_actual_copied, df_imputed_j_high_drop])

    # Restore the actual end point
    df_imputed = df_imputed.join(
        df_start_end_all.rename(
            {train_qrtr[-1]: "START", forecast_qrtr[-1]: "END"}, axis=1
        )
    )
    df_imputed[forecast_qrtr[-1]] = df_imputed["END"]
    df_imputed = df_imputed[forecast_qrtr]

    return df_imputed


def identify_jcodes_high_growth(
    df_model_forecast, forecast_qrtr, j_lastQ_actual_copied
):
    """
    Identify J_CODES with high forecast growth.

    Args:
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.
        forecast_qrtr (list): List of forecast quarters.
        j_lastQ_actual_copied (list): List of J_CODES with last quarter actuals copied.

    Returns:
        list: List of J_CODES with high forecast growth.
    """
    # Pivot the forecast dataframe
    df_model_forecast_pivot = df_model_forecast.pivot(
        index="J_CODE", columns="Quarter", values="ASP_Pred"
    )

    # Filter out growing forecasts
    df_model_forecast_pivot = df_model_forecast_pivot[
        df_model_forecast_pivot[forecast_qrtr[-1]]
        > df_model_forecast_pivot[forecast_qrtr[0]]
    ]

    # Filter HIGH growth J_CODES
    df_model_forecast_pivot_high_growth = df_model_forecast_pivot[
        (
            (
                df_model_forecast_pivot[forecast_qrtr[-1]]
                / df_model_forecast_pivot[forecast_qrtr[0]]
            )
            ** (1 / 8)
            - 1
            > 0.03
        )
    ]

    # Extract J_CODES with high growth excluding those with last quarter actuals copied
    j_high_growth = list(df_model_forecast_pivot_high_growth.index)
    j_high_growth = [c for c in j_high_growth if c not in j_lastQ_actual_copied]

    return j_high_growth


def impute_high_growth(
    df_actual_train_val, df_model_forecast, j_high_growth, train_qrtr, forecast_qrtr
):
    """
    Impute high growth forecasts using actual and forecasted growth rates.

    Args:
        df_actual_train_val (pandas.DataFrame): DataFrame containing actual training/validation data.
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.
        j_high_growth (list): List of J_CODES with high growth forecasts.
        train_qrtr (list): List of training/validation quarters.
        forecast_qrtr (list): List of forecast quarters.

    Returns:
        pandas.DataFrame: DataFrame containing imputed high growth forecasts.
    """

    # Calculate actual growth rate over the last 2 years
    df_actual_high_growth = df_actual_train_val.pivot(
        index="J_CODE", columns="Quarter", values="ASP_true"
    ).loc[j_high_growth]
    df_actual_high_growth["growth"] = (
        df_actual_high_growth[train_qrtr[-1]] / df_actual_high_growth[train_qrtr[-8]]
    ) ** (1 / 8) - 1
    df_actual_high_growth = df_actual_high_growth[["growth"]]
    df_actual_high_growth.columns = ["growth_actual"]

    # Calculate forecast growth rate
    df_forecast_high_growth = df_model_forecast.pivot(
        index="J_CODE", columns="Quarter", values="ASP_Pred"
    ).loc[j_high_growth]
    df_forecast_high_growth["growth"] = (
        df_forecast_high_growth[forecast_qrtr[-1]]
        / df_forecast_high_growth[forecast_qrtr[0]]
    ) ** (1 / 8) - 1
    df_forecast_high_growth = df_forecast_high_growth[["growth"]]
    df_forecast_high_growth.columns = ["growth_forecast"]

    # Aggregate and cap forecasted growth rate
    df_high_growth = df_actual_high_growth.join(df_forecast_high_growth)
    df_high_growth["growth_forecast_capped"] = df_high_growth["growth_forecast"].map(
        lambda x: x if np.abs(x) <= 0.03 else 0.03
    )
    df_high_growth["growth_avg"] = df_high_growth[
        ["growth_actual", "growth_forecast_capped"]
    ].mean(1)
    df_high_growth["growth_avg_capped"] = df_high_growth["growth_avg"].map(
        lambda x: x if np.abs(x) <= 0.03 else 0.03
    )

    # Extract last training quarter ASP
    df_high_growth_lastQ_actual = df_actual_train_val.pivot(
        index="J_CODE", columns="Quarter", values="ASP_true"
    ).loc[j_high_growth][[train_qrtr[-1]]]
    df_high_growth_lastQ_actual = df_high_growth_lastQ_actual.loc[j_high_growth]

    # Adjust forecast by capped growth
    df_imputed_geo = pd.DataFrame(index=j_high_growth, columns=[forecast_qrtr])
    for q in range(len(df_imputed_geo.columns)):
        df_imputed_geo[df_imputed_geo.columns[q]] = df_high_growth_lastQ_actual[
            train_qrtr[-1]
        ] * ((df_high_growth["growth_avg_capped"] + 1) ** (q + 1))

    df_imputed = (
        df_model_forecast.pivot(index="J_CODE", columns="Quarter", values="ASP_Pred")
        .loc[j_high_growth]
        .values
        * 0.25
        + df_imputed_geo.loc[j_high_growth].values * 0.75
    )
    df_imputed = pd.DataFrame(df_imputed, index=j_high_growth, columns=forecast_qrtr)

    return df_imputed


def imputation_constant_high_drop(
    df_actual_train_val, df_model_forecast, train_qrtr, forecast_qrtr
):
    """
    Perform imputation for constant drop forecasts.

    Args:
        df_actual_train_val (pandas.DataFrame): DataFrame containing actual training/validation data.
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.
        train_qrtr (list): List of training/validation quarters.
        forecast_qrtr (list): List of forecast quarters.

    Returns:
        pandas.DataFrame: DataFrame containing imputed forecasts for constant drop.
    """
    # Identify J_CODES with constant forecast for 8 quarters and first quarter forecast same as last quarter actual
    j_lastQ_actual_copied = identify_jcodes_constant_forecast(
        df_actual_train_val, df_model_forecast, train_qrtr, forecast_qrtr
    )

    # Identify J_CODES with a significant drop (more than 20%) in forecast
    j_high_drop = identify_jcodes_with_highdrop(df_model_forecast, forecast_qrtr)

    # Define start and end points for forecasting
    df_start_end_all = define_start_end_point(
        df_actual_train_val,
        df_model_forecast,
        j_lastQ_actual_copied,
        j_high_drop,
        train_qrtr,
        forecast_qrtr,
    )

    # Impute constant drop forecasts
    df_imputed_1 = impute_constant_drop(
        df_start_end_all,
        df_model_forecast,
        j_lastQ_actual_copied,
        j_high_drop,
        train_qrtr,
        forecast_qrtr,
    )

    return df_imputed_1


def imputation_high_growth(
    df_actual_train_val,
    df_model_forecast,
    train_qrtr,
    forecast_qrtr,
    j_lastQ_actual_copied,
):
    """
    Perform imputation for high growth forecasts.

    Args:
        df_actual_train_val (pandas.DataFrame): DataFrame containing actual training/validation data.
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.
        train_qrtr (list): List of training/validation quarters.
        forecast_qrtr (list): List of forecast quarters.
        j_lastQ_actual_copied (list): List of J_CODES with last quarter actuals copied.

    Returns:
        pandas.DataFrame: DataFrame containing imputed forecasts for high growth.
    """
    # Identify J_CODES with high forecast growth
    j_high_growth = identify_jcodes_high_growth(
        df_model_forecast, forecast_qrtr, j_lastQ_actual_copied
    )

    # Impute high growth forecasts
    df_imputed_2 = impute_high_growth(
        df_actual_train_val, df_model_forecast, j_high_growth, train_qrtr, forecast_qrtr
    )

    return df_imputed_2


def create_smoothened_forecast(df_actual_train_val, df_model_forecast):
    """
    Create a smoothened forecast by imputing constant high drop and high growth forecasts.

    Args:
        df_actual_train_val (pandas.DataFrame): DataFrame containing actual training/validation data.
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.

    Returns:
        pandas.DataFrame: DataFrame containing the smoothened forecast.
    """
    # Identify unique quarters in training and forecast data
    train_qrtr = list(
        df_actual_train_val[["Quarter"]]
        .drop_duplicates()
        .sort_values(by="Quarter")
        .values.reshape(-1)
    )
    forecast_qrtr = list(
        df_model_forecast[["Quarter"]]
        .drop_duplicates()
        .sort_values(by="Quarter")
        .values.reshape(-1)
    )

    # Impute constant high drop forecasts
    df_imputed_1 = imputation_constant_high_drop(
        df_actual_train_val, df_model_forecast, train_qrtr, forecast_qrtr
    )

    # Identify J_CODES with last quarter actuals copied
    j_lastQ_actual_copied = list(df_imputed_1.index)

    # Impute high growth forecasts
    df_imputed_2 = imputation_high_growth(
        df_actual_train_val,
        df_model_forecast,
        train_qrtr,
        forecast_qrtr,
        j_lastQ_actual_copied,
    )

    # Concatenate imputed forecasts
    df_output_imputation = pd.concat([df_imputed_1, df_imputed_2])

    # Reshape the dataframe
    df_output_imputation = pd.melt(df_output_imputation.reset_index(), id_vars="index")
    df_output_imputation.columns = ["J_CODE", "Quarter", "ASP_Forecast_Adjusted"]
    df_output_imputation = df_output_imputation.sort_values(["J_CODE", "Quarter"])

    # Extract unimputed forecasts from the model forecast data
    df_model_unimputed = df_model_forecast[
        ~df_model_forecast["J_CODE"].isin(df_output_imputation["J_CODE"].unique())
    ][["J_CODE", "Quarter", "ASP_Pred"]]
    df_model_unimputed.columns = ["J_CODE", "Quarter", "ASP_Pred"]

    # Rename columns for imputed forecasts
    df_model_imputed = df_output_imputation
    df_model_imputed.columns = ["J_CODE", "Quarter", "ASP_Pred"]

    # Concatenate unimputed and imputed forecasts
    df_model_smoothened = pd.concat([df_model_unimputed, df_model_imputed])

    return df_model_smoothened


def convert_to_quarter(date_str):
    """
    Convert a date string to a quarter format (YYYYQX).

    Args:
        date_str (str): The input date string in the format "MM/DD/YYYY".

    Returns:
        str: The quarter format representation of the input date.
    """
    # Convert the input date string to a datetime object
    date_object = datetime.strptime(date_str, "%m/%d/%Y")

    # Extract the year and quarter from the datetime object
    year = date_object.year
    quarter = (date_object.month - 1) // 3 + 1

    # Format the result as "YYYYQX"
    result = f"{year}Q{quarter}"

    return result


def convert_to_date(quarter_str):
    """
    Convert a quarter format (YYYYQX) to a date string (MM/DD/YYYY).

    Args:
        quarter_str (str): The input quarter format string in the format "YYYYQX".

    Returns:
        str: The date string representation of the input quarter.
    """
    # Extract the year and quarter from the input string
    year, quarter = map(int, quarter_str.split("Q"))

    # Calculate the month corresponding to the start of the quarter
    month = (quarter - 1) * 3 + 1

    # Create a datetime object for the first day of the quarter
    date_object = datetime(year, month, 1)

    # Format the result as "MM/DD/YYYY"
    result = date_object.strftime("%m/%d/%Y")

    return result


def adjust_for_market_event(df_market_event, df_model_forecast):
    """
    Adjust the forecast for market events.

    Args:
        df_market_event (pandas.DataFrame): DataFrame containing market event data.
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.

    Returns:
        pandas.DataFrame: DataFrame containing adjusted forecasts for market events.
    """

    # Convert month to quarter
    df_market_event["Quarter"] = df_market_event["Month"].map(convert_to_quarter)

    # Filter market events for forecast quarters
    forecast_qrtr = list(
        df_model_forecast[["Quarter"]]
        .drop_duplicates()
        .sort_values(by="Quarter")
        .values.reshape(-1)
    )
    df_market_event = df_market_event[df_market_event["Quarter"].isin(forecast_qrtr)]

    # Calculate months since forecast start
    month_fc_strt = convert_to_date(forecast_qrtr[0])
    df_market_event["mnth_snce_fc_start"] = (
        (
            pd.to_datetime(df_market_event["Month"]) - pd.to_datetime(month_fc_strt)
        ).dt.days
        / 31
    ).astype(int)
    df_market_event["mnth_snce_fc_start"] = (
        df_market_event["mnth_snce_fc_start"] + 1 + 3
    )

    # Determine market event flags
    df_market_event["comp_launch_in_fc_flag"] = (
        (df_market_event["time_since_last_comp_launch"] > 0)
        & (
            df_market_event["time_since_last_comp_launch"]
            <= df_market_event["mnth_snce_fc_start"]
        )
    ).astype(int)

    df_market_event["loe_in_fc_flag"] = (
        (df_market_event["time_since_last_loe"] > 0)
        & (
            df_market_event["time_since_last_loe"]
            <= df_market_event["mnth_snce_fc_start"]
        )
    ).astype(int)

    df_market_event["same_class_launch_in_fc_flag"] = (
        (df_market_event["time_since_same_class_launch"] > 0)
        & (
            df_market_event["time_since_same_class_launch"]
            <= df_market_event["mnth_snce_fc_start"]
        )
    ).astype(int)

    df_market_event["market_event_flag"] = (
        df_market_event[
            ["comp_launch_in_fc_flag", "loe_in_fc_flag", "same_class_launch_in_fc_flag"]
        ].sum(1)
        > 0
    ).astype(int)

    # Get J_CODES for which market event occurred during forecasting period
    j_codes_to_adjust_market_event = df_market_event[
        df_market_event["market_event_flag"] > 0
    ]["J_CODE"].unique()

    df_model_forecast.reset_index(drop=True, inplace=True)
    # Get J_CODES for which unscaled forecast captures the drop
    df_model_forecast_pivot = df_model_forecast.pivot(
        index="J_CODE", columns="Quarter", values="ASP_pred_unscaled"
    )
    j_codes_to_adjust_drop = df_model_forecast_pivot[
        df_model_forecast_pivot[forecast_qrtr[-1]]
        <= df_model_forecast_pivot[forecast_qrtr[0]]
    ].index

    # Get J_CODES for which scaled forecast is to be adjusted
    j_codes_to_adjust = list(
        set(j_codes_to_adjust_market_event).intersection(set(j_codes_to_adjust_drop))
    )

    # Filter forecast table to adjust
    df_model_forecast_to_event_adjust = df_model_forecast[
        df_model_forecast["J_CODE"].isin(j_codes_to_adjust)
    ]

    # Weighted average of scaled & unscaled forecast with varying weights over forecasting horizon
    dict_weight_scaled = dict(
        zip(forecast_qrtr, [1, 1, 0.5, 0.5, 0.25, 0.25, 0.25, 0.25])
    )
    df_model_forecast_to_event_adjust[
        "weight_scaled"
    ] = df_model_forecast_to_event_adjust["Quarter"].map(dict_weight_scaled)
    df_model_forecast_to_event_adjust["weight_unscaled"] = (
        1 - df_model_forecast_to_event_adjust["weight_scaled"]
    )

    df_model_forecast_to_event_adjust[
        "ASP_Pred_Adjusted"
    ] = df_model_forecast_to_event_adjust.apply(
        lambda x: x["ASP_pred_scaled"] * x["weight_scaled"]
        + x["ASP_pred_unscaled"] * x["weight_unscaled"],
        axis=1,
    )

    return df_model_forecast_to_event_adjust[["J_CODE", "Quarter", "ASP_Pred_Adjusted"]]


def post_process(df_actual_train_val, df_model_forecast, df_market_event):
    """
    Perform post-processing on the model forecasts.

    Args:
        df_actual_train_val (pandas.DataFrame): DataFrame containing actual training/validation data.
        df_model_forecast (pandas.DataFrame): DataFrame containing model forecasts.
        df_market_event (pandas.DataFrame): DataFrame containing market event data.

    Returns:
        pandas.DataFrame: DataFrame containing post-processed forecasts.
    """
    df_actual_train_val["Quarter"] = df_actual_train_val["Quarter"].astype(str)
    df_model_forecast["Quarter"] = df_model_forecast["Quarter"].astype(str)
    # Remove actual training/validation data that overlaps with forecast data
    df_actual_train_val = df_actual_train_val[
        ~df_actual_train_val["Quarter"].isin(df_model_forecast["Quarter"])
    ]

    # Impute negative forecasts
    df_model_forecast = impute_negative_forecast(df_model_forecast, df_actual_train_val)

    # Adjust for market events
    df_model_forecast_to_event_adjust = adjust_for_market_event(
        df_market_event, df_model_forecast
    )
    df_model_forecast_to_event_adjust.columns = ["J_CODE", "Quarter", "ASP_Pred"]

    # Smoothen forecasts
    df_smoothened_forecast_scaled = create_smoothened_forecast(
        df_actual_train_val,
        df_model_forecast.rename({"ASP_pred_scaled": "ASP_Pred"}, axis=1),
    )
    df_smoothened_forecast_scaled = df_smoothened_forecast_scaled.rename(
        {"ASP_Pred": "ASP_pred_scaled"}, axis=1
    )

    df_smoothened_forecast_unscaled = create_smoothened_forecast(
        df_actual_train_val,
        df_model_forecast.rename({"ASP_pred_unscaled": "ASP_Pred"}, axis=1),
    )
    df_smoothened_forecast_unscaled = df_smoothened_forecast_unscaled.rename(
        {"ASP_Pred": "ASP_pred_unscaled"}, axis=1
    )

    df_smoothened_forecast = df_smoothened_forecast_scaled.merge(
        df_smoothened_forecast_unscaled, on=["J_CODE", "Quarter"]
    )

    # Exclude j_codes that were adjusted for market events
    df_smoothened_forecast_no_event_adjust = df_smoothened_forecast[
        ~df_smoothened_forecast["J_CODE"].isin(
            df_model_forecast_to_event_adjust["J_CODE"]
        )
    ]
    df_smoothened_forecast_no_event_adjust = (
        df_smoothened_forecast_no_event_adjust.drop("ASP_pred_unscaled", axis=1).rename(
            {"ASP_pred_scaled": "ASP_Pred"}, axis=1
        )
    )

    # Combine adjusted and unadjusted forecasts
    df_forecast_post_processed = pd.concat(
        [df_smoothened_forecast_no_event_adjust, df_model_forecast_to_event_adjust]
    )

    return df_forecast_post_processed
