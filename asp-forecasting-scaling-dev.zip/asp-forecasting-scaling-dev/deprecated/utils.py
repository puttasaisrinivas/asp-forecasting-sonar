import warnings

warnings.filterwarnings("ignore")

import numpy as np
import pandas as pd
import pyspark.pandas as ps
from datetime import datetime, timedelta

from tqdm import tqdm

tqdm.pandas()

from pmdarima.arima import auto_arima

from sklearn.preprocessing import StandardScaler
from xgboost import XGBRegressor

from typing import List, Any


def read_data(path_config, name_index):
    """
    Read data from various files based on the provided configuration.

    Args:
        path_config (str): File path to the configuration file.
        name_sheet (str): Name of the sheet in the configuration file to read from.
        name_index (str): Name of the index column in the configuration file.

    Returns:
        dict: A dictionary containing various dataframes and values read from different files.
            - master_data (pd.DataFrame or pa.Table): Master data dataframe containing exhaustive features corresponding to each jcode.
            - asp_data (pd.DataFrame or pa.Table): Dataframe containing product name and other features at jcode level.
            - ep_data (pd.DataFrame): DataFrame containing external information like competitor launch details and patent expiry details.
            - lst_selected_products (pd.DataFrame): Dataframe containing the list of selected products.
            - lst_prioritized_products (pd.DataFrame): Dataframe containing the list of prioritized products.
            - forecast_month_start (str): Start month for the forecast.
            - forecast_months (str): Number of forecast months.

    Note:
        - The file paths in the configuration file should be enclosed in double quotes ("").
        - The master_data and asp_data can be either pandas DataFrame or PyArrow Table, depending on the file format.
    """

    # Read the configuration CSV file
    asp_config = pd.read_csv(path_config)

    # Extract file paths from the configuration
    master_data_path = asp_config.loc[
        asp_config[name_index] == "master_data", "File Path"
    ].iloc[0][1:-1]
    asp_data_path = asp_config.loc[
        asp_config[name_index] == "asp_data", "File Path"
    ].iloc[0][1:-1]
    ep_data_path = asp_config.loc[
        asp_config[name_index] == "ep_data", "File Path"
    ].iloc[0][1:-1]
    lst_selected_products_path = asp_config.loc[
        asp_config[name_index] == "lst_selected_products", "File Path"
    ].iloc[0][1:-1]
    lst_prioritized_products_path = asp_config.loc[
        asp_config[name_index] == "lst_prioritized_products", "File Path"
    ].iloc[0][1:-1]
    forecast_month_start = asp_config.loc[
        asp_config[name_index] == "forecast_month_start", "File Path"
    ].iloc[0][1:-1]
    forecast_months = asp_config.loc[
        asp_config[name_index] == "forecast_months", "File Path"
    ].iloc[0]

    if ".csv" in master_data_path:
        master_data = pd.read_csv(master_data_path)
    else:
        master_data = ps.read_table(master_data_path).to_pandas()

    if ".csv" in asp_data_path:
        asp_data = pd.read_csv(asp_data_path)
    else:
        asp_data = ps.read_table(asp_data_path).to_pandas()

    # Read data from CSV files
    ep_data = pd.read_csv(ep_data_path)
    lst_selected_products = pd.read_csv(lst_selected_products_path)
    lst_prioritized_products = pd.read_csv(lst_prioritized_products_path)

    # Convert forecast_months to int
    forecast_months = int(forecast_months)

    # Create a dictionary containing the read data
    dict_data_read = {
        "master_data": master_data,
        "asp_data": asp_data,
        "ep_data": ep_data,
        "lst_selected_products": lst_selected_products,
        "lst_prioritized_products": lst_prioritized_products,
        "forecast_month_start": forecast_month_start,
        "forecast_months": forecast_months,
    }
    return dict_data_read


def get_config(
    generic_flag: bool, forecast_month_start: str, forecast_months: int
) -> dict:
    """
    Generate configuration dictionary based on provided parameters.

    Args:
        generic_flag (bool): Flag indicating whether the analysis is for generic products.
        forecast_month_start (str): Start month for the forecast.
        forecast_months (int): Number of forecast months.

    Returns:
        dict: A dictionary containing configuration parameters for the analysis.

    Notes:
        - For generic products, the target variable is "ASP_growth" and static columns include basic product information.
        - For non-generic products, the target variable is "ASP_true" and static columns include more detailed product information.
        - The window size for generic products is set to 2, while for non-generic products it is set to 24.
    """
    config_dict = {
        "forecast_month_start": forecast_month_start,
        "forecast_months": forecast_months,
        "time_series_columns": ["Residual"],
        "time_series": "Residual",
        "forecast_for_priotized_products_only": True,
        "time_cap": 36,
    }

    if generic_flag:
        config_dict.update(
            {
                "target_variable": "ASP_growth",
                "static_columns": ["PRODUCT_NAME", "THERA_CLS_DSCR", "DISEASE_STATE"],
                "window_size": 2,
            }
        )
    else:
        config_dict.update(
            {
                "target_variable": "ASP_true",
                "static_columns": [
                    "PRODUCT_NAME",
                    "THERA_CLS_DSCR",
                    "MSPN_DOSG_FORM",
                    "MSPN_ROA",
                    "USC5_DSCR",
                    "DISEASE_STATE",
                ],
                "window_size": 24,
            }
        )

    return config_dict


def process_market_event_features(market_event_features: pd.DataFrame) -> pd.DataFrame:
    """
    Process market event features like data obtained from Evaluate Pharma

    Args:
        market_event_features (pd.DataFrame): Market event features dataframe.

    Returns:
        pd.DataFrame: Processed market event features dataframe.

    Note:
        - The market_event_features dataframe should contain the following columns:
            - CALENDAR_DATE: Date of the market event.
            - J_CODE: Code corresponding to the market event.
            - time_since_last_comp_launch: Time since the last competitor launch.
            - time_to_next_comp_launch: Time to the next competitor launch.
            - time_since_last_loe: Time since the last loss of exclusivity.
            - time_to_next_loe: Time to the next loss of exclusivity.
            - time_since_same_class_launch: Time since the last launch in the same class.

    """
    market_event_features_processed = market_event_features.copy()

    market_event_features_processed["CALENDAR_DATE"] = pd.to_datetime(
        market_event_features_processed["CALENDAR_DATE"]
    )
    market_event_features_processed.rename(
        columns={"CALENDAR_DATE": "Month"}, inplace=True
    )

    market_event_features_processed["J_CODE"] = market_event_features_processed[
        "J_CODE"
    ].astype(str)

    market_event_features_processed = market_event_features_processed.sort_values(
        by=["J_CODE", "Month"]
    )
    market_event_features_processed = market_event_features_processed.reset_index(
        drop=True
    )

    market_event_features_processed = (
        market_event_features_processed.groupby(["J_CODE", "Month"])
        .agg(
            {
                "time_since_last_comp_launch": "first",
                "time_to_next_comp_launch": "first",
                "time_since_last_loe": "first",
                "time_to_next_loe": "first",
                "time_since_same_class_launch": "first",
            }
        )
        .reset_index()
    )

    market_event_features_processed = market_event_features_processed.sort_values(
        by=["J_CODE", "Month"]
    )
    market_event_features_processed = market_event_features_processed.reset_index(
        drop=True
    )

    return market_event_features_processed


def process_master_data(
    master_data: pd.DataFrame, data_market_event_features: pd.DataFrame
) -> pd.DataFrame:
    """
    Process master data and merge with market event features.

    Args:
        master_data (pd.DataFrame): DataFrame containing master data.
        data_market_event_features (pd.DataFrame): DataFrame containing market event features.

    Returns:
        pd.DataFrame: Processed master data DataFrame.

    Notes:
        - The function performs the following processing steps:
            1. Orders columns in the master data DataFrame.
            2. Renames the 'CALENDAR_DATE' column to 'Month'.
            3. Converts date columns to datetime format.
            4. Groups the DataFrame by 'J_CODE' and 'Month' and selects the first row.
            5. Calculates quarterly ASP (Average Selling Price) from ASP_PRICE column.
            6. Calculates time-based features such as time since launch date, time difference from patent expiry,
               and time since generic launch date.
            7. Merges the processed master data with market event features.
    """

    # Order columns in master data DataFrame
    cols_ordered_list = [
        "J_CODE",
        "CALENDAR_DATE",
        "Month",
        "YR_MONTH",
        "POST_DT",
        "PRODUCT_NAME",
        "ASP_PRICE",
        "CODE_DOSAGE",
        "PACK_SIZE",
        "PACK_QTY",
        "GNRC_IND",
        "ndc_count",
        "generic_ndc_count",
        "Generic_Launch",
        "PATENT_EXPIR_DT",
        "Tentative_Launch_Date",
        "EXCLUSIVITY_EXPIR_DT",
        "Generic_Launch_Date_final",
        "Patent_Expiry",
        "DISEASE_STATE",
        "Brand_Generic",
        "Product_Launch_Date",
        "Estimated_LOE_Date",
        "Biologics_Indicator",
        "Combined_Molecule",
        "Acute_Chronic",
        "THERA_CLS_DSCR",
        "PROD_HIER1",
        "PROD_HIER2",
        "PROD_HEIR3",
        "NUM_PROVIDERS",
        "MSPN_DOSG_FORM",
        "MSPN_ROA",
        "USC5_DSCR",
        "ASP_YR",
        "ASP_MNTH",
        "Quarter",
    ]
    df_t2 = master_data[cols_ordered_list]

    # Rename 'Month' column to 'Month'
    df_t2.rename(columns={"Month": "Month_2"}, inplace=True)

    # Convert date columns to datetime format
    date_columns = [
        "CALENDAR_DATE",
        "POST_DT",
        "YR_MONTH",
        "Generic_Launch_Date_final",
        "Patent_Expiry",
        "Tentative_Launch_Date",
    ]
    df_t2[date_columns] = df_t2[date_columns].apply(pd.to_datetime)
    df_t2.rename(columns={"CALENDAR_DATE": "Month"}, inplace=True)
    df_t2["J_CODE"] = df_t2["J_CODE"].astype(str)
    # Group DataFrame by 'J_CODE' and 'Month' and select first row
    df_t2 = df_t2.groupby(["J_CODE", "Month"]).head(1).reset_index(drop=True)
    df_t2 = df_t2.sort_values(by=["J_CODE", "Month"])
    df_t2 = df_t2.reset_index(drop=True)

    # Calculate quarterly ASP from ASP_PRICE column
    df_t2["Quarter"] = df_t2["Month"].dt.to_period("Q")
    df_t2["ASP_PRICE"] = df_t2.groupby(["J_CODE", "Quarter"])["ASP_PRICE"].transform(
        lambda x: x.fillna(method="ffill")
    )
    df_t2["ASP_PRICE"] = df_t2.groupby(["J_CODE", "Quarter"])["ASP_PRICE"].transform(
        lambda x: x.fillna(method="bfill")
    )

    df_t2["Month_Q"] = df_t2["Month"].map(lambda x: str(x).split("-")[1]).astype(int)
    df_t2["Month_Q"] = df_t2["Month_Q"] - df_t2["Quarter"].map(
        df_t2.groupby(["Quarter"])["Month_Q"].min()
    )
    df_t2["ASP_true"] = df_t2.apply(
        lambda x: x["ASP_PRICE"] if x["Month_Q"] == 0 else np.nan, axis=1
    )
    df_t2["ASP_true"] = (
        df_t2.groupby(["J_CODE"])
        .apply(lambda x: x["ASP_true"].astype(float).interpolate(method="linear"))
        .reset_index()["ASP_true"]
        .values
    )

    # Calculate time-based features
    grouped = df_t2.groupby("J_CODE")
    df_t2["time_since_launch_date"] = grouped.apply(
        lambda x: (x["Month"] - x["Tentative_Launch_Date"].max()).dt.days
    ).reset_index(drop=True)
    df_t2["time_diff_patent_expiry"] = grouped.apply(
        lambda x: (x["Patent_Expiry"].max() - x["Month"]).dt.days
    ).reset_index(drop=True)
    df_t2["time_since_generic_launch_date"] = grouped.apply(
        lambda x: (x["Month"] - x["Generic_Launch_Date_final"].max()).dt.days
    ).reset_index(drop=True)
    del grouped

    df_t2["J_CODE"] = df_t2["J_CODE"].astype("str").astype("object")
    data_market_event_features["J_CODE"] = (
        data_market_event_features["J_CODE"].astype("str").astype("object")
    )
    # Fill missing values in 'ASP_true' column
    df_t2["ASP_true"] = df_t2.groupby("J_CODE")["ASP_true"].transform(
        lambda x: x.fillna(method="ffill")
    )

    # Calculate ASP growth
    df_t2["ASP_lagged"] = (
        df_t2.sort_values(["J_CODE", "Month"]).groupby(["J_CODE"])["ASP_true"].shift(1)
    )
    df_t2["ASP_growth"] = df_t2["ASP_true"] / df_t2["ASP_lagged"]
    df_t2.drop(columns=["ASP_lagged"], inplace=True)

    # Merge processed master data with market event features
    df_t2 = pd.merge(
        df_t2,
        data_market_event_features[
            [
                "J_CODE",
                "Month",
                "time_since_last_comp_launch",
                "time_since_last_loe",
                "time_since_same_class_launch",
            ]
        ].rename(
            {
                "time_since_last_comp_launch": "time_since_last_comp_launch_in_months",
                "time_since_last_loe": "time_since_last_loe_in_months",
                "time_since_same_class_launch": "time_since_same_class_launch_in_months",
            },
            axis=1,
        ),
        on=["J_CODE", "Month"],
        how="outer",
    )
    return df_t2


def update_ep_data(ep_data_processed: pd.DataFrame) -> pd.DataFrame:
    """
    Update the ep_data_processed DataFrame by replacing certain values in the 'J_CODE' column.

    Args:
        ep_data_processed (pd.DataFrame): DataFrame containing processed ep_data.

    Returns:
        pd.DataFrame: Updated ep_data_processed DataFrame.

    Notes:
        - The function replaces values in the 'J_CODE' column as follows:
            - Replaces values in the 'J_CODE' column with values from 'available_in_ep' list with
              corresponding values from the 'not_available_in_ep' list.
    """
    available_in_ep = ["J8501", "J7613", "J8521", "J9070"]
    not_available_in_ep = ["J1453", "J7620", "J8520", "J8530"]

    ep_data_replace = ep_data_processed.copy()

    # Exclude 'not_available_in_ep' values from DataFrame
    ep_data_replace = ep_data_replace[
        ~ep_data_replace["J_CODE"].isin(not_available_in_ep)
    ]

    # Replace 'available_in_ep' values with corresponding 'not_available_in_ep' values
    ep_data_replace_replacement = ep_data_replace[
        ep_data_replace["J_CODE"].isin(available_in_ep)
    ]
    ep_data_replace_replacement["J_CODE"] = ep_data_replace_replacement[
        "J_CODE"
    ].replace(available_in_ep, not_available_in_ep)

    # Concatenate updated DataFrame with replaced values
    ep_data_updated = pd.concat([ep_data_replace, ep_data_replace_replacement], axis=0)

    return ep_data_updated


def process_ep_data(ep_data, asp_data, start_date, forecast_months):
    """
    Process EP data to generate additional features based on given ASP data and forecast months.

    Args:
        ep_data (pd.DataFrame): DataFrame containing EP data.
        asp_data (pd.DataFrame): DataFrame containing ASP data.
        start_date (str or pd.Timestamp): Start date for forecasting.
        forecast_months (int): Number of months to forecast.

    Returns:
        pd.DataFrame: Updated EP data with additional features.
    """
    # Read EP Data
    new_row = {"J_CODE": "J9330", "First Launch (USA)": pd.to_datetime("2007-01-01")}
    # Add the new row to the DataFrame
    ep_data = ep_data.append(new_row, ignore_index=True)

    # Convert date columns to datetime
    ep_data_date_cols = [
        "US Indication Launch",
        "First Launch (USA)",
        "Patent Expiry",
        "Tentative Generic Launch Date (Based on EP Data)",
        "Tentative Launch Date ",
    ]
    for col in ep_data_date_cols:
        ep_data[col] = pd.to_datetime(ep_data[col])

    # Convert ASP data date column to datetime
    asp_data["CALENDAR_DATE"] = pd.to_datetime(asp_data["CALENDAR_DATE"])

    # Generate additional months data
    test_months = pd.DataFrame(
        generate_month_year_list(start_date, forecast_months), columns=["CALENDAR_DATE"]
    )
    test_months["CALENDAR_DATE"] = pd.to_datetime(test_months["CALENDAR_DATE"])
    test_months["key"] = 1
    primary_key_cols = ["J_CODE", "PRODUCT_NAME", "CALENDAR_DATE"]

    # Merge additional months data with product data
    df = asp_data[primary_key_cols].drop_duplicates()
    df_product = pd.DataFrame({"J_CODE": df["J_CODE"].unique(), "key": 1})
    df_product_test = (
        df_product.merge(test_months, on="key")
        .drop("key", axis=1)
        .sort_values(["J_CODE", "CALENDAR_DATE"])
    )
    df_product_test = df_product_test.merge(
        df[["J_CODE", "PRODUCT_NAME"]].drop_duplicates(), on="J_CODE", how="left"
    )

    # Concatenate additional data to the existing data
    df = pd.concat([df, df_product_test], axis=0)
    df2 = df.merge(ep_data, on="J_CODE", how="left")

    # Feature generation
    date_col_to_consider1 = "First Launch (USA)"
    date_col_to_consider2 = "Patent Expiry"

    # Implementation of feature generation...
    df3_1 = df2[df2[date_col_to_consider1] < df2["CALENDAR_DATE"]]
    df3_1 = df3_1.groupby(primary_key_cols)[date_col_to_consider1].max().reset_index()
    df3_1["time_since_last_comp_launch"] = round(
        (df3_1["CALENDAR_DATE"] - df3_1[date_col_to_consider1]).dt.days / 30
    )

    df3_2 = df2[df2[date_col_to_consider1] > df2["CALENDAR_DATE"]]
    df3_2 = df3_2.groupby(primary_key_cols)[date_col_to_consider1].min().reset_index()
    df3_2["time_to_next_comp_launch"] = round(
        (df3_2[date_col_to_consider1] - df3_2["CALENDAR_DATE"]).dt.days / 30
    )

    df3_3 = df2[df2[date_col_to_consider2] < df2["CALENDAR_DATE"]]
    df3_3 = df3_3.groupby(primary_key_cols)[date_col_to_consider2].max().reset_index()
    df3_3["time_since_last_loe"] = round(
        (df3_3["CALENDAR_DATE"] - df3_3[date_col_to_consider2]).dt.days / 30
    )

    df3_3[df3_3["J_CODE"] == "90371"].sort_values(
        by=primary_key_cols, ascending=[True, True, True]
    )
    df3_4 = df2[df2[date_col_to_consider2] > df2["CALENDAR_DATE"]]
    df3_4 = df3_4.groupby(primary_key_cols)[date_col_to_consider2].min().reset_index()
    df3_4["time_to_next_loe"] = round(
        (df3_4[date_col_to_consider2] - df3_4["CALENDAR_DATE"]).dt.days / 30
    )

    df3_temp = df2[df2[date_col_to_consider1] <= df2["CALENDAR_DATE"]]
    df3_temp = (
        df3_temp.groupby(["CALENDAR_DATE", "Mechanism of Action"])[
            date_col_to_consider1
        ]
        .max()
        .reset_index()
    )
    df3_temp["time_since_same_class_launch"] = round(
        (df3_temp["CALENDAR_DATE"] - df3_temp[date_col_to_consider1]).dt.days / 30
    )
    df3_5 = (
        df2[primary_key_cols + ["Mechanism of Action"]]
        .drop_duplicates()
        .merge(df3_temp, on=["CALENDAR_DATE", "Mechanism of Action"], how="inner")
    )

    # Merge generated features with EP data
    processed_ep_data = df2[primary_key_cols].merge(
        df3_1, on=primary_key_cols, how="left"
    )
    processed_ep_data = processed_ep_data.merge(df3_2, on=primary_key_cols, how="left")
    processed_ep_data = processed_ep_data.merge(df3_3, on=primary_key_cols, how="left")
    processed_ep_data = processed_ep_data.merge(df3_4, on=primary_key_cols, how="left")
    processed_ep_data = processed_ep_data.merge(df3_5, on=primary_key_cols, how="left")
    processed_ep_data = processed_ep_data[
        [
            "J_CODE",
            "CALENDAR_DATE",
            "time_since_last_comp_launch",
            "time_to_next_comp_launch",
            "time_since_last_loe",
            "time_to_next_loe",
            "time_since_same_class_launch",
        ]
    ]
    processed_ep_data = processed_ep_data.drop_duplicates()

    # Call update_ep_data function
    updated_ep_data = update_ep_data(processed_ep_data)
    return updated_ep_data


def generate_month_year_list(start_date: str, num_months: int) -> List[str]:
    """
    Generate a list of month-year strings starting from the given start date.

    Args:
        start_date (str): Start date in the format 'YYYY-MM'.
        num_months (int): Number of months to generate.

    Returns:
        List[str]: List of month-year strings.

    Raises:
        ValueError: If the start_date format is invalid.

    Notes:
        - Each month-year string is formatted as 'YYYY-MM'.
        - Assumes each month has 30 days for simplicity.
    """
    # Generate month-year list
    current_date = datetime.strptime(start_date, "%Y-%m")
    month_year_list = []
    for _ in range(num_months):
        month_year_list.append(current_date.strftime("%Y-%m"))
        current_date += timedelta(
            days=31
        )  # Assuming each month has 31 days for simplicity

    return month_year_list


def create_train_test_month_quarters(
    start_forecast_month: str, forecast_months: int, processed_master_data: pd.DataFrame
):
    """
    Create train and test months and quarters based on the forecast start month and duration.

    Args:
        start_forecast_month (str): Start month for the forecast in 'YYYY-MM' format.
        forecast_months (int): Number of forecast months.
        processed_master_data (pd.DataFrame): Processed master data containing the 'Month' column.

    Returns:
        train_months (List[str]): List of train months in 'YYYY-MM' format.
        test_months (List[str]): List of test months in 'YYYY-MM' format.
        train_quarters (List[str]): List of train quarters in 'YYYY-Q' format.
        test_quarters (List[str]): List of test quarters in 'YYYY-Q' format.

    Raises:
        ValueError: If the start_forecast_month format is invalid or forecast_months is non-positive.

    Notes:
        - The train months are calculated based on the available data up to the forecast start month.
        - The test months are generated starting from the forecast start month.
    """
    # Validate forecast months
    if forecast_months <= 0:
        raise ValueError("forecast_months must be a positive integer.")

    end_date = pd.to_datetime(start_forecast_month) + pd.DateOffset(
        months=forecast_months - 1
    )

    available_data_months = processed_master_data["Month"].unique()
    available_data_months = [
        np.datetime_as_string(date, unit="M")[:7] for date in available_data_months
    ]

    all_months = processed_master_data[processed_master_data["Month"] < end_date][
        "Month"
    ].unique()
    all_months = [np.datetime_as_string(date, unit="M")[:7] for date in all_months]

    test_months = generate_month_year_list(start_forecast_month, forecast_months)
    train_months = sorted(list(set(set(all_months) - set(test_months))))

    train_quarters = pd.to_datetime(train_months, format="%Y-%m").to_period("Q")
    train_quarters = sorted(list(set(train_quarters.astype("str"))))

    test_quarters = pd.to_datetime(test_months, format="%Y-%m").to_period("Q")
    test_quarters = sorted(list(set(test_quarters.astype("str"))))

    print("===========================================")
    print("Train quarters:", train_quarters)
    print("===========================================")
    print("Forecast quarters:", sorted(list(set(test_quarters) - set(train_quarters))))
    print("===========================================")

    return train_months, test_months, train_quarters, test_quarters


def find_best_forecasting_model_autoarima(
    pivot_data: pd.DataFrame, product_id: str, forecast_months: int
) -> pd.DataFrame:
    """
    Find the best forecasting model using auto_arima and generate predictions.

    Args:
        pivot_data (pd.DataFrame): Pivot table data with 'Month' as index and product IDs as columns.
        product_id (str): ID of the product for which to generate forecasts.
        forecast_months (int): Number of months to forecast.

    Returns:
        pd.DataFrame: DataFrame containing actual and predicted ASP values, along with residuals.

    Raises:
        ValueError: If the product_id is not found in the pivot_data or if the forecast_months is non-positive.

    Notes:
        - The function uses auto_arima to automatically select the best ARIMA model for forecasting.
        - It generates predictions for the specified number of forecast months.
    """

    arima_data = pivot_data.copy()
    arima_data_actual = arima_data.copy()
    arima_data.iloc[-forecast_months:, 1:] = np.NaN

    arima_data = arima_data.set_index("Month")
    arima_data_actual = arima_data_actual.set_index("Month")

    asp_values = arima_data[product_id]
    asp_values_actual = arima_data_actual[product_id]

    total_months = len(asp_values)
    train_months_len = total_months - forecast_months
    train_data = asp_values[:train_months_len].dropna()

    # Fit auto_arima model
    model = auto_arima(
        train_data,
        seasonal=True,
        m=1,
        stepwise=True,
        trace=False,
        error_action="ignore",
    )

    # Generate forecasts
    forecast_train = model.predict_in_sample(return_conf_int=False)
    forecast, conf_int = model.predict(n_periods=forecast_months, return_conf_int=True)
    forecast_all = forecast_train.append(forecast)

    # Merge actual and predicted ASP values
    arima_forecast_op_data = pd.merge(
        pd.DataFrame(
            {"Month": asp_values_actual.index, "Actual_ASP": asp_values_actual.values}
        ),
        pd.DataFrame(
            {"Month": forecast_all.index, "Arima_Predicted_ASP": forecast_all.values}
        ),
        on="Month",
        how="left",
    )
    arima_forecast_op_data["J_CODE"] = product_id

    # Arrange columns and calculate residuals
    arima_forecast_op_data = arima_forecast_op_data[
        ["J_CODE", "Month", "Actual_ASP", "Arima_Predicted_ASP"]
    ]
    arima_forecast_op_data["J_CODE"] = arima_forecast_op_data["J_CODE"].astype(str)
    arima_forecast_op_data["Month"] = pd.to_datetime(arima_forecast_op_data["Month"])
    arima_forecast_op_data = arima_forecast_op_data.sort_values(by=["J_CODE", "Month"])
    arima_forecast_op_data = arima_forecast_op_data.reset_index(drop=True)
    arima_forecast_op_data["Residual"] = (
        arima_forecast_op_data["Actual_ASP"]
        - arima_forecast_op_data["Arima_Predicted_ASP"]
    )

    return arima_forecast_op_data


def train_and_predict_with_arima(
    processed_master_data: pd.DataFrame,
    forecast_months: int,
    target_variable: str,
    time_series_columns: list,
) -> pd.DataFrame:
    """
    Train and predict with ARIMA model for each product in the processed_master_data.

    Args:
        processed_master_data (pd.DataFrame): Processed master data with columns including 'Month', 'J_CODE', and 'ASP_true'.
        forecast_months (int): Number of months to forecast.
        target_variable (str): The target variable to be used for training the ARIMA model.
        time_series_columns (list): List of columns representing time series data.

    Returns:
        pd.DataFrame: DataFrame containing actual ASP values, ARIMA predicted ASP values, and residuals.

    Notes:
        - The function trains an ARIMA model for each product based on the provided target variable.
        - It generates predictions for the specified number of forecast months.
    """
    # Pivot the processed master data
    processed_master_data_pivot_data = pd.pivot(
        data=processed_master_data,
        index="Month",
        columns="J_CODE",
        values=target_variable,
    ).reset_index()
    processed_master_data_pivot_data.sort_values(by=["Month"], inplace=True)

    forecast_results = []
    for product_id in tqdm(processed_master_data_pivot_data.columns[1:]):
        # Find the best forecasting model using auto_arima
        arima_output = find_best_forecasting_model_autoarima(
            processed_master_data_pivot_data.copy(), product_id, forecast_months
        )
        forecast_results.append(arima_output)

    # Concatenate forecast results
    arima_predicted_forecast = pd.concat(forecast_results)
    arima_predicted_forecast["J_CODE"] = arima_predicted_forecast["J_CODE"].astype(str)
    arima_predicted_forecast["Month"] = pd.to_datetime(
        arima_predicted_forecast["Month"]
    )
    arima_predicted_forecast = arima_predicted_forecast.sort_values(
        by=["J_CODE", "Month"]
    )
    arima_predicted_forecast = arima_predicted_forecast.reset_index(drop=True)

    # Merge with actual ASP values from processed_master_data
    processed_master_data["J_CODE"] = (
        processed_master_data["J_CODE"].astype(str).astype("object")
    )
    arima_predicted_forecast = pd.merge(
        arima_predicted_forecast,
        processed_master_data[["J_CODE", "Month", "ASP_true"]],
        on=["J_CODE", "Month"],
        how="left",
    )

    # Fill missing values in time series columns with forward fill
    arima_predicted_forecast[time_series_columns] = arima_predicted_forecast.groupby(
        ["J_CODE"]
    )[time_series_columns].transform(lambda x: x.fillna(method="ffill"))

    return arima_predicted_forecast


def get_static_features(
    processed_master_data: pd.DataFrame,
    generic_flag: bool,
    forecast_months: int,
    static_columns: list,
) -> pd.DataFrame:
    """
    Extract static features from the processed master data.

    Args:
        processed_master_data (pd.DataFrame): Processed master data containing necessary columns.
        generic_flag (bool): A flag indicating whether the generic features should be extracted.
        forecast_months (int): Number of months to forecast.
        static_columns (list): List of static columns to be extracted.

    Returns:
        pd.DataFrame: DataFrame containing static features for each product.

    Notes:
        - The function extracts static features based on the provided generic flag and static columns.
        - It filters the data based on the training period defined by the forecast months.
        - Static columns are imputed with mode values within each product group.
        - Product hierarchy columns are aggregated and reduced to the top 15 values.
    """
    train_last_month = str(
        processed_master_data["Month"].unique()[-forecast_months]
    ).split("T")[0]

    if generic_flag:
        static_feature_data = processed_master_data[
            [
                "J_CODE",
                "Month",
                "PRODUCT_NAME",
                "THERA_CLS_DSCR",
                "DISEASE_STATE",
                "PROD_HIER1",
                "PROD_HIER2",
                "PROD_HEIR3",
            ]
        ]
        static_feature_data = static_feature_data[
            static_feature_data["Month"] < train_last_month
        ]
        static_feature_data = static_feature_data[
            [
                "J_CODE",
                "PRODUCT_NAME",
                "THERA_CLS_DSCR",
                "DISEASE_STATE",
                "PROD_HIER1",
                "PROD_HIER2",
                "PROD_HEIR3",
            ]
        ]
    else:
        static_feature_data = processed_master_data[
            [
                "J_CODE",
                "Month",
                "PRODUCT_NAME",
                "THERA_CLS_DSCR",
                "MSPN_DOSG_FORM",
                "MSPN_ROA",
                "USC5_DSCR",
                "DISEASE_STATE",
                "PROD_HIER1",
                "PROD_HIER2",
                "PROD_HEIR3",
            ]
        ]
        static_feature_data = static_feature_data[
            static_feature_data["Month"] < train_last_month
        ]
        static_feature_data = static_feature_data[
            [
                "J_CODE",
                "PRODUCT_NAME",
                "THERA_CLS_DSCR",
                "MSPN_DOSG_FORM",
                "MSPN_ROA",
                "USC5_DSCR",
                "DISEASE_STATE",
                "PROD_HIER1",
                "PROD_HIER2",
                "PROD_HEIR3",
            ]
        ]

    for column in static_columns:
        static_feature_data[column] = static_feature_data.groupby("J_CODE")[
            column
        ].transform(lambda x: x.mode().values[0] if len(x.mode()) > 0 else np.NaN)

    static_hierarchy_columns = ["PROD_HIER1", "PROD_HIER2", "PROD_HEIR3"]
    static_data_hierarchy = static_feature_data[
        ["J_CODE"] + static_hierarchy_columns
    ].drop_duplicates(subset=["J_CODE"], keep="last")
    static_feature_data["J_CODE"] = (
        static_feature_data["J_CODE"].astype(str).astype("object")
    )
    static_data_hierarchy["J_CODE"] = (
        static_data_hierarchy["J_CODE"].astype(str).astype("object")
    )

    static_feature_data = pd.merge(
        static_feature_data.drop(columns=["PROD_HIER1", "PROD_HIER2", "PROD_HEIR3"]),
        static_data_hierarchy,
        how="left",
        on="J_CODE",
    )

    static_feature_data["PROD_HIER1"] = static_feature_data["PROD_HIER1"].where(
        static_feature_data["PROD_HIER1"].isin(
            static_feature_data["PROD_HIER1"].value_counts().head(15).index
        ),
        "others",
    )

    static_feature_data.drop(["PROD_HIER2", "PROD_HEIR3"], axis=1, inplace=True)
    static_feature_data = static_feature_data.drop_duplicates().reset_index(drop=True)

    return static_feature_data


def get_market_event_features_for_generic(processed_master_data, time_cap):
    """
    Extract market event features for generics from processed master data.

    Args:
        processed_master_data (pd.DataFrame): Processed master data containing relevant features.
        time_cap (int): Time cap in months.

    Returns:
        pd.DataFrame: DataFrame containing market event features for generics.
    """
    # List of market event features
    market_event_features_list = [
        "time_since_last_comp_launch_in_months",
        "time_since_last_loe_in_months",
        "time_since_same_class_launch_in_months",
    ]

    # Extract relevant columns from processed master data
    market_event_features_data = processed_master_data[
        ["J_CODE", "Month"] + market_event_features_list
    ]

    # Columns to be capped
    capping_cols = [
        "time_since_last_comp_launch_in_months",
        "time_since_last_loe_in_months",
        "time_since_same_class_launch_in_months",
    ]

    # Apply capping to columns
    for col in capping_cols:
        market_event_features_data[col] = [
            x if x <= time_cap else 0 for x in market_event_features_data[col]
        ]

    return market_event_features_data


def transform_data(predicted_arima_forecast, time_series_columns, test_months):
    """
    Transform predicted ARIMA forecast data for model input.

    Args:
        predicted_arima_forecast (pd.DataFrame): Predicted ARIMA forecast data.
        time_series_columns (list): List of time series columns to include in transformation.
        test_months (list): List of test months for forecasting.

    Returns:
        StandardScaler: Scaler object fitted on the training data.
        pd.DataFrame: Transformed and scaled forecast data.
        pd.DataFrame: Transformed but unscaled forecast data.

    Notes:
        - The function transforms the predicted ARIMA forecast data by stacking and unstacking.
        - It scales the data using StandardScaler based on the training months.
    """
    # Subset the relevant columns
    predicted_arima_forecast_subset = predicted_arima_forecast[
        ["J_CODE", "Month"] + time_series_columns
    ]

    # Convert Month to YearMonth and set index
    predicted_arima_forecast_subset["YearMonth"] = predicted_arima_forecast_subset[
        "Month"
    ].dt.to_period("M")
    predicted_arima_forecast_subset.set_index(["J_CODE", "YearMonth"], inplace=True)

    # Stack and unstack the data
    transformed_df = (
        predicted_arima_forecast_subset.stack(dropna=False)
        .unstack(level=1)
        .reset_index()
    )

    # Group by J_CODE and remove first row (NaN after unstacking)
    transformed_df = (
        transformed_df.groupby("J_CODE")
        .apply(lambda x: x.iloc[1:])
        .reset_index(drop=True)
        .rename(columns={"level_1": "Time_Series"})
    )

    # Rename columns to string and set test month values to NaN
    transformed_df.columns = transformed_df.columns.astype(str)
    transformed_df[test_months] = np.nan

    # Sort and reset index
    transformed_df.sort_values(by=["J_CODE", "Time_Series"], inplace=True)
    transformed_df = transformed_df.reset_index(drop=True)
    transformed_df = transformed_df.set_index(["J_CODE", "Time_Series"])

    # Scale the data using StandardScaler
    scaler = StandardScaler()

    transformed_df_scaled = pd.DataFrame(
        scaler.fit_transform(transformed_df.T),
        index=transformed_df.columns,
        columns=transformed_df.index,
    )
    transformed_df_scaled = transformed_df_scaled.T.reset_index()

    # Return scaler and transformed data (scaled and unscaled)
    transformed_df_unscaled = (
        transformed_df_scaled  # For consistency with the previous implementation
    )
    return scaler, transformed_df_scaled, transformed_df_unscaled


def prepare_sliding_window_data_for_xgboost(
    transformed_data: pd.DataFrame,
    market_event_feature_data: pd.DataFrame,
    static_feature_data: pd.DataFrame,
    sliding_window_size: int,
    generic_flag: bool,
    time_series: str,
) -> pd.DataFrame:
    """
    Prepare sliding window data for XGBoost model training.

    Args:
        transformed_data (pd.DataFrame): Transformed data containing time series information.
        market_event_feature_data (pd.DataFrame): Market event feature data.
        static_feature_data (pd.DataFrame): Static feature data.
        sliding_window_size (int): Size of the sliding window.
        generic_flag (bool): A flag indicating whether generic features should be used.
        time_series (str): Name of the time series column.

    Returns:
        pd.DataFrame: Prepared sliding window feature data.

    Notes:
        - The function prepares sliding window data for XGBoost model training.
        - It joins static and market event feature data to the sliding window data.
        - Categorical columns are converted to categorical data types.
    """
    # Filter transformed data based on time series
    transformed_data = transformed_data[
        transformed_data["Time_Series"] == time_series
    ].drop(columns=["Time_Series"])

    month_cols = [c for c in transformed_data.columns if "-" in c]
    i = 0
    data = []

    # Iterate through sliding window
    for i in range(len(month_cols) - sliding_window_size):
        start_month = month_cols[i]
        end_month = month_cols[i + sliding_window_size - 1]
        target_month = month_cols[i + sliding_window_size]

        # Prepare X and Y data
        x = pd.DataFrame(
            transformed_data.loc[:, start_month:end_month].values,
            index=transformed_data.J_CODE,
            columns=[f"{str(c)}_{time_series}" for c in range(sliding_window_size)],
        )
        y = pd.DataFrame(
            transformed_data.loc[:, target_month].values,
            index=transformed_data.J_CODE,
            columns=[time_series],
        )
        xy = x.join(y)
        xy["window_start"] = start_month
        xy["window_end"] = end_month
        xy["target_month"] = target_month
        data.append(xy)

    data = pd.concat(data)
    data = (
        data.reset_index()
        .sort_values(by=["J_CODE", "target_month"])
        .set_index(["J_CODE", "window_start", "window_end", "target_month"])
    )

    # Join static feature data
    if generic_flag:
        data_all = data.join(
            static_feature_data[
                ["J_CODE", "THERA_CLS_DSCR", "DISEASE_STATE", "PROD_HIER1"]
            ].set_index("J_CODE")
        )
        market_event_feature_data = market_event_feature_data.rename(
            columns={"Month": "target_month"}
        )
        data_all = data_all.join(
            market_event_feature_data.set_index(["J_CODE", "target_month"])
        )
    else:
        data_all = data.join(
            static_feature_data[
                [
                    "J_CODE",
                    "THERA_CLS_DSCR",
                    "MSPN_DOSG_FORM",
                    "MSPN_ROA",
                    "USC5_DSCR",
                    "DISEASE_STATE",
                    "PROD_HIER1",
                    "time_since_last_comp_launch_train_flag",
                    "time_since_last_loe_train_flag",
                ]
            ].set_index("J_CODE")
        )

    # Convert data types
    categorical_columns = list(static_feature_data.columns[2:])
    numerical_col = list(set(data_all.columns) - set(categorical_columns))
    data_all[numerical_col] = data_all[numerical_col].astype(float)

    # Prepare window-wise feature data
    window_wise_feature_data = data_all.copy()
    window_wise_feature_data = window_wise_feature_data.reset_index()
    window_wise_feature_data.set_index(["J_CODE", "target_month"], inplace=True)
    window_wise_feature_data = window_wise_feature_data.T.drop_duplicates().T
    window_wise_feature_data[categorical_columns] = window_wise_feature_data[
        categorical_columns
    ].astype("category")
    window_wise_feature_data["month_feature"] = (
        window_wise_feature_data.reset_index()["target_month"]
        .map(lambda x: int(str(x).split("-")[-1]))
        .values
    )
    numerical_col = list(
        set(window_wise_feature_data.columns[2:]) - set(categorical_columns)
    )
    window_wise_feature_data[numerical_col] = window_wise_feature_data[
        numerical_col
    ].astype(float)

    return window_wise_feature_data


def get_train_test_data(window_wise_feature_data, test_months, time_series_columns):
    """
    Get train and test data for model training and evaluation.

    Args:
        window_wise_feature_data (pd.DataFrame): Window-wise feature data.
        test_months (list): List of months to be used for testing.
        time_series_columns (list): List of time series columns.

    Returns:
        tuple: A tuple containing X_train and y_train DataFrames.

    Raises:
        ValueError: If the input data is not provided or is empty.

    Notes:
        - The function filters the window-wise feature data based on test months.
        - It separates features and target variables for both training and testing datasets.
    """

    exclude_columns = [
        "J_CODE",
        "window_start",
        "window_end",
        "target_month",
    ] + time_series_columns

    # Filter training data
    window_wise_feature_data_train = window_wise_feature_data[
        ~window_wise_feature_data.index.get_level_values("target_month").isin(
            test_months
        )
    ]

    # Separate features and target variables for training data
    X_train = window_wise_feature_data_train.drop(
        columns=[
            c for c in window_wise_feature_data_train.columns if c in exclude_columns
        ]
    )
    y_train = window_wise_feature_data_train[time_series_columns]

    return X_train, y_train


def train_xgb(X_train, y_train):
    """
    Train an XGBoost model using the provided training data.

    Args:
        X_train (pd.DataFrame): Features for training.
        y_train (pd.DataFrame): Target variables for training.

    Returns:
        XGBRegressor: Trained XGBoost model.

    Raises:
        ValueError: If the input data is not provided or is invalid.
    """
    # Filter out rows with NaN target values
    idx = y_train.isna().sum(1)
    idx = idx[idx == 0].index

    # Train XGBoost model
    model = XGBRegressor(enable_categorical=True)
    model.fit(X_train.loc[idx], y_train.loc[idx])

    return model


def get_feature_importance(model):
    """
    Get feature importances from a trained model.

    This function calculates and returns feature importances based on the model's feature names
    and their respective importances.

    Args:
        model: Trained model object with `feature_names_in_` and `feature_importances_` attributes.

    Returns:
        pd.DataFrame: DataFrame containing feature names and their corresponding importances.
    """
    # Create DataFrame with feature names and importances
    feature_importances = pd.DataFrame(
        {"Feature": model.feature_names_in_, "importance": model.feature_importances_}
    )

    # Normalize importances to percentages
    feature_importances["importance"] = (
        feature_importances["importance"]
        * 100
        / feature_importances["importance"].sum()
    )

    # Sort feature importances in descending order
    feature_importances.sort_values(by=["importance"], ascending=False, inplace=True)

    return feature_importances


def get_xgb_predictions(
    window_wise_feature_data,
    model,
    window_size,
    processed_master_data,
    X_train,
    y_train,
    test_months,
    forecast_months,
    time_series_columns,
):
    """
    Get XGBoost predictions for the specified forecast period.

    Args:
        window_wise_feature_data (pd.DataFrame): Window-wise feature data.
        model: Trained XGBoost model.
        window_size (int): Size of the sliding window.
        processed_master_data (pd.DataFrame): Processed master data.
        X_train (pd.DataFrame): Features of the training data.
        y_train (pd.DataFrame): Target variables of the training data.
        test_months (list): List of months to be used for testing.
        forecast_months (int): Number of months to forecast.
        time_series_columns (list): List of time series columns.

    Returns:
        pd.DataFrame: DataFrame containing XGBoost predictions.

    Notes:
        - This function generates predictions using the trained XGBoost model for the specified forecast period.
        - It iterates over the forecast period, updating the predictions and window-wise feature data accordingly.
    """
    exclude_columns = [
        "J_CODE",
        "window_start",
        "window_end",
        "target_month",
    ] + time_series_columns

    predictions = []
    window_wise_feature_data_test_i = window_wise_feature_data[
        window_wise_feature_data.index.get_level_values("target_month")
        == test_months[0]
    ]

    for i in range(forecast_months):
        # Drop irrelevant columns
        window_wise_feature_data_test_i = window_wise_feature_data_test_i.drop(
            columns=[
                c
                for c in window_wise_feature_data_test_i.columns
                if c in exclude_columns
            ]
        )

        # Make predictions
        y_pred = model.predict(window_wise_feature_data_test_i)
        y_pred = pd.DataFrame(
            data=y_pred,
            index=window_wise_feature_data_test_i.index,
            columns=y_train.columns,
        )
        predictions.append(y_pred)

        # Update data for the next prediction
        y_pred_tt = y_pred.reset_index().copy()
        y_pred_tt["target_month"] = pd.to_datetime(y_pred_tt["target_month"])
        y_pred_tt["update_month"] = y_pred_tt["target_month"] + pd.DateOffset(months=1)
        y_pred_tt["update_month"] = (
            y_pred_tt["update_month"].dt.to_period("M").astype(str)
        )
        y_pred_tt = y_pred_tt.set_index(["J_CODE", "update_month"]).drop(
            columns=["target_month"]
        )

        window_wise_feature_data_test_prev_month = (
            window_wise_feature_data_test_i.copy()
        )
        cols_to_update = [
            c
            for c in window_wise_feature_data_test_i.columns
            if (str(window_size - 1) + "_") in c and ("USC5_DSCR" not in c)
        ]

        try:
            window_wise_feature_data_test_i = window_wise_feature_data[
                window_wise_feature_data.index.get_level_values("target_month")
                == test_months[i + 1]
            ]
        except IndexError:
            break

        y_pred_tt = y_pred_tt.loc[window_wise_feature_data_test_i.index]
        window_wise_feature_data_test_i[cols_to_update] = y_pred_tt[["Residual"]].values

        col_idx = window_wise_feature_data_test_i.isna().sum()
        col_idx = col_idx[col_idx == processed_master_data.J_CODE.nunique()].index
        col_idx = [c for c in col_idx if c in X_train.columns]

        if len(col_idx) > 0:
            past_col_idx = [
                str(int(c.split("_")[0]) + 1) + "_" + "_".join(c.split("_")[1:])
                for c in col_idx
            ]
            window_wise_feature_data_test_i[
                col_idx
            ] = window_wise_feature_data_test_prev_month.loc[
                window_wise_feature_data_test_i.index.get_level_values("J_CODE")
            ][past_col_idx].values

        col_idx = window_wise_feature_data_test_i[X_train.columns].isna().sum()
        col_idx = col_idx[col_idx > 0]

    xgb_predicted_data = pd.concat(predictions).reset_index()
    return xgb_predicted_data


def aggregate_predictions(xgb_pred_data, arima_predicted_data, scaler, scaling):
    """
    Function to aggregate XGBoost and ARIMA predicted data and perform post-processing.

    Args:
        xgb_pred_data (pd.DataFrame): XGBoost predicted data with columns "target_month", "J_CODE", "Residual".
        arima_predicted_data (pd.DataFrame): ARIMA predicted data with columns "J_CODE", "Month", "Arima_Predicted_ASP".
        scaler (object): Scaler object used for scaling the data.
        scaling (bool): Flag indicating whether data was scaled.

    Returns:
        pd.DataFrame: Aggregated and post-processed predicted data with columns "J_CODE", "Month", "Residual_predicted_xgb",
                      "Arima_Predicted_ASP", "Final_Predicted_ASP".
    """
    # Rename columns
    xgb_pred_data = xgb_pred_data.rename(
        {"target_month": "Month", "Residual": "Residual_predicted_xgb"}, axis=1
    )

    # Convert "Month" column to datetime
    xgb_pred_data["Month"] = pd.to_datetime(xgb_pred_data["Month"])

    # Sort by "J_CODE" and "Month"
    xgb_pred_data.sort_values(["J_CODE", "Month"], inplace=True)

    # Add "YearMonth" column
    xgb_pred_data["YearMonth"] = xgb_pred_data["Month"].dt.to_period("M")

    # Set index as "J_CODE" and "YearMonth"
    xgb_pred_data.set_index(["J_CODE", "YearMonth"], inplace=True)

    # Perform data transformation
    xgb_pred_data_transformed = (
        xgb_pred_data.stack(dropna=False).unstack(level=1).reset_index()
    )
    xgb_pred_data_transformed = (
        xgb_pred_data_transformed.groupby("J_CODE")
        .apply(lambda x: x.iloc[1:])
        .reset_index(drop=True)
        .rename(columns={"level_1": "Time_Series"})
    )

    xgb_pred_data_transformed.columns = xgb_pred_data_transformed.columns.astype(str)
    xgb_pred_data_transformed.sort_values(by=["J_CODE", "Time_Series"], inplace=True)
    xgb_pred_data_transformed = xgb_pred_data_transformed.reset_index(drop=True)
    xgb_pred_data_transformed = xgb_pred_data_transformed.set_index(
        ["J_CODE", "Time_Series"]
    )

    # Perform data inverse scaling
    if scaling:
        xgb_pred_data_inverse_scaled = pd.DataFrame(
            scaler.inverse_transform(xgb_pred_data_transformed.T),
            index=xgb_pred_data_transformed.columns,
            columns=xgb_pred_data_transformed.index,
        )
    else:
        xgb_pred_data_inverse_scaled = xgb_pred_data_transformed.T
    xgb_pred_data_inverse_scaled = xgb_pred_data_inverse_scaled.T

    # Reshape the data
    xgb_pred_data_inverse_scaled_retransformed = xgb_pred_data_inverse_scaled.stack(
        dropna=False
    ).reset_index()
    xgb_pred_data_inverse_scaled_retransformed.columns = [
        "J_CODE",
        "Time_Series",
        "Month",
        "Residual_predicted_xgb",
    ]
    xgb_pred_data_inverse_scaled_retransformed["Month"] = pd.to_datetime(
        xgb_pred_data_inverse_scaled_retransformed["Month"]
    )
    xgb_pred_data_inverse_scaled_retransformed.drop(
        columns=["Time_Series"], inplace=True
    )
    xgb_pred_data_inverse_scaled_retransformed = (
        xgb_pred_data_inverse_scaled_retransformed.set_index(["J_CODE", "Month"])
    )
    xgb_pred_data_inverse_scaled_retransformed = (
        xgb_pred_data_inverse_scaled_retransformed.reset_index()
    )
    xgb_pred_data_inverse_scaled_retransformed = (
        xgb_pred_data_inverse_scaled_retransformed.set_index(["J_CODE", "Month"])
    )

    # Set index of ARIMA predicted data
    arima_predicted_data = arima_predicted_data.set_index(["J_CODE", "Month"])

    # Merge XGBoost and ARIMA predicted data
    prediction_post_processed = pd.merge(
        xgb_pred_data_inverse_scaled_retransformed.reset_index(),
        arima_predicted_data.reset_index(),
        on=["J_CODE", "Month"],
        how="left",
    )

    # Drop unnecessary columns
    prediction_post_processed.drop(columns=["Residual"], inplace=True)

    # Calculate final predicted ASP
    prediction_post_processed["Final_Predicted_ASP"] = (
        prediction_post_processed["Arima_Predicted_ASP"]
        + prediction_post_processed["Residual_predicted_xgb"]
    )

    return prediction_post_processed


def retransform_predictions(
    aggregated_predictions, processed_master_data, generic_flag
):
    """
    Retransform aggregated predictions to obtain final forecasted ASP.

    Args:
        aggregated_predictions (pd.DataFrame): DataFrame containing aggregated predictions.
        processed_master_data (pd.DataFrame): Processed master data.
        generic_flag (bool): A flag indicating whether generic features are used.

    Returns:
        pd.DataFrame: DataFrame containing retransformed predictions.

    Notes:
        - This function retransforms aggregated predictions to obtain final forecasted ASP.
        - If generic_flag is True, it adjusts the final predicted ASP based on the previous true ASP values.
    """
    if generic_flag:
        if "Final_Predicted_ASP" not in aggregated_predictions.columns:
            aggregated_predictions["Final_Predicted_ASP"] = None

        group_list = []
        for name, group in aggregated_predictions.groupby("J_CODE"):
            first_row_index = group.index[0]
            group.at[first_row_index, "Final_Predicted_ASP"] = (
                group.at[first_row_index, "Final_Predicted_ASP"]
                * processed_master_data[
                    (processed_master_data["J_CODE"] == name)
                    & (
                        processed_master_data["Month"]
                        == group.Month.iloc[0] + pd.DateOffset(months=-1)
                    )
                ]["ASP_true"].values[0]
            )
            for i in group.index[1:]:
                group.loc[i, "Final_Predicted_ASP"] = (
                    group.loc[i - 1, "Final_Predicted_ASP"]
                    * group.loc[i, "Final_Predicted_ASP"]
                )
            group_list.append(group)

        predictions_retransformed = pd.concat(group_list)
        predictions_retransformed = predictions_retransformed.rename(
            {"ASP_true": "Actual_ASP_new"}, axis=1
        )
        predictions_retransformed = (
            predictions_retransformed.groupby(
                ["J_CODE", predictions_retransformed["Month"].dt.to_period("Q")]
            )
            .agg({"Final_Predicted_ASP": "mean", "Actual_ASP_new": "first"})
            .reset_index()
        )
    else:
        predictions_retransformed = (
            aggregated_predictions.groupby(
                ["J_CODE", aggregated_predictions["Month"].dt.to_period("Q")]
            )
            .agg({"Final_Predicted_ASP": "mean", "Actual_ASP": "first"})
            .reset_index()
        )

    predictions_retransformed.columns = [
        "J_CODE",
        "Time",
        "ASP_forecasted_mean",
        "Actual",
    ]
    predictions_retransformed.sort_values(["J_CODE", "Time"], inplace=True)

    return predictions_retransformed


def generate_launch_flag_data(launch_data, train_data_end_quarter):
    """
    Generate launch flag data for model training.

    Args:
        launch_data (pd.DataFrame): DataFrame containing launch data.
        train_data_end_quarter (str): End quarter of the training data.

    Returns:
        pd.DataFrame: DataFrame containing launch flag data for training.

    Notes:
        - This function preprocesses launch data, aggregates it, and generates binary flags for training.
    """
    # Data preprocessing steps for launch_data
    launch_data["J_CODE"] = launch_data["J_CODE"].astype(str)
    launch_data["Month"] = pd.to_datetime(launch_data["Month"])
    launch_data["Quarter"] = launch_data["Month"].dt.to_period("Q")
    launch_data = launch_data.sort_values(by=["J_CODE", "Month", "Quarter"])
    launch_data = launch_data.reset_index(drop=True)
    launch_data["Quarter"] = launch_data["Quarter"].astype(str)

    # Aggregate launch_data based on 'J_CODE' and 'Quarter'
    launch_data_agg = (
        launch_data.groupby(["J_CODE", "Quarter"])
        .agg(
            {
                "time_since_last_comp_launch": "first",
                "time_to_next_comp_launch": "first",
                "time_since_last_loe": "first",
                "time_to_next_loe": "first",
            }
        )
        .reset_index()
    )

    # Split data into training and testing sets based on quarters
    launch_data_agg_train = launch_data_agg[
        launch_data_agg["Quarter"] <= train_data_end_quarter
    ]
    launch_data_agg_test = launch_data_agg[
        launch_data_agg["Quarter"] > train_data_end_quarter
    ]

    # Convert time-related columns to the J_CODE level min value on train data
    launch_data_agg_train = (
        launch_data_agg_train.groupby("J_CODE")
        .agg(
            {
                "time_since_last_comp_launch": "min",
                "time_to_next_comp_launch": "min",
                "time_since_last_loe": "min",
                "time_to_next_loe": "min",
            }
        )
        .reset_index()
    )

    # Apply conditions using lambda functions to create binary flags for train data
    launch_data_agg_train["time_since_last_comp_launch"] = launch_data_agg_train[
        "time_since_last_comp_launch"
    ].apply(lambda x: 1 if x <= 3 else 0 if not pd.isna(x) else -1)
    launch_data_agg_train["time_to_next_comp_launch"] = launch_data_agg_train[
        "time_to_next_comp_launch"
    ].apply(lambda x: 1 if x <= 3 else 0 if not pd.isna(x) else -1)
    launch_data_agg_train["time_since_last_loe"] = launch_data_agg_train[
        "time_since_last_loe"
    ].apply(lambda x: 1 if x <= 3 else 0 if not pd.isna(x) else -1)
    launch_data_agg_train["time_to_next_loe"] = launch_data_agg_train[
        "time_to_next_loe"
    ].apply(lambda x: 1 if x <= 3 else 0 if not pd.isna(x) else -1)

    # Rename columns
    new_column_names = [
        "J_CODE",
        "time_since_last_comp_launch_train",
        "time_to_next_comp_launch_train",
        "time_since_last_loe_train",
        "time_to_next_loe_train",
    ]
    launch_data_agg_train.columns = new_column_names

    return launch_data_agg_train


def update_event_features_for_non_generic(
    static_feature_data, market_event_data, train_data_end_quarter
):
    """
    Update event features for non-generic products.

    Args:
        static_feature_data (pd.DataFrame): Static feature data for products.
        market_event_data (pd.DataFrame): Market event data.
        train_data_end_quarter (str): End quarter of the training data.

    Returns:
        pd.DataFrame: Updated static feature data.

    Notes:
        - This function generates lag-based flag data from market event data and merges it with static feature data.
        - It is designed for non-generic products.
    """
    # Generate lag-based flag data from market event data
    lag_based_flag_data = generate_launch_flag_data(
        market_event_data, train_data_end_quarter
    )
    lag_based_flag_data["J_CODE"] = lag_based_flag_data["J_CODE"].astype(str)
    lag_based_flag_data = lag_based_flag_data[
        ["J_CODE", "time_since_last_comp_launch_train", "time_since_last_loe_train"]
    ]
    lag_based_flag_data = lag_based_flag_data.rename(
        {
            "time_since_last_comp_launch_train": "time_since_last_comp_launch_train_flag",
            "time_since_last_loe_train": "time_since_last_loe_train_flag",
        },
        axis=1,
    )

    # Update data types
    static_feature_data["J_CODE"] = static_feature_data["J_CODE"].astype("object")
    lag_based_flag_data["J_CODE"] = lag_based_flag_data["J_CODE"].astype("object")

    # Merge lag-based flag data with static feature data
    static_feature_data = pd.merge(
        static_feature_data, lag_based_flag_data, on="J_CODE", how="left"
    )

    return static_feature_data


def train_and_predict_residuals_xgb(
    transformed_data,
    market_event_feature_data,
    static_feature_data,
    master_data_processed,
    arima_predicted_data,
    config_dict,
    generic_flag,
    test_months,
    scaler,
    scaling_flag,
):
    """
    Train an XGBoost model and predict residuals.

    Args:
        transformed_data (pd.DataFrame): Transformed time series data.
        market_event_feature_data (pd.DataFrame): Market event feature data.
        static_feature_data (pd.DataFrame): Static feature data.
        master_data_processed (pd.DataFrame): Processed master data.
        arima_predicted_data (pd.DataFrame): ARIMA predicted data.
        config_dict (dict): Configuration dictionary.
        generic_flag (bool): Flag indicating generic or non-generic products.
        test_months (list): List of months for testing.
        scaler (StandardScaler): Scaler object for scaling features.
        scaling_flag (bool): Flag indicating whether scaling is applied.

    Returns:
        pd.DataFrame: Retransformed predictions.

    Notes:
        - This function trains an XGBoost model, predicts residuals, aggregates predictions,
          retransforms them, and returns the final predictions.
    """
    # Prepare sliding window data for XGBoost
    window_wise_feature_data = prepare_sliding_window_data_for_xgboost(
        transformed_data=transformed_data,
        market_event_feature_data=market_event_feature_data,
        static_feature_data=static_feature_data,
        sliding_window_size=config_dict["window_size"],
        generic_flag=generic_flag,
        time_series=config_dict["time_series"],
    )

    # Get train and test data
    X_train, y_train = get_train_test_data(
        window_wise_feature_data=window_wise_feature_data,
        test_months=test_months,
        time_series_columns=config_dict["time_series_columns"],
    )

    # Train XGBoost model
    model = train_xgb(X_train=X_train, y_train=y_train)

    # Get feature importances
    # feature_importances = get_feature_importance(model)

    # Get XGBoost predictions
    xgb_predicted_data = get_xgb_predictions(
        window_wise_feature_data=window_wise_feature_data,
        model=model,
        window_size=config_dict["window_size"],
        processed_master_data=master_data_processed,
        X_train=X_train,
        y_train=y_train,
        test_months=test_months,
        forecast_months=config_dict["forecast_months"],
        time_series_columns=config_dict["time_series_columns"],
    )

    # Aggregate XGBoost predictions with ARIMA predictions
    predictions_aggregated = aggregate_predictions(
        xgb_pred_data=xgb_predicted_data,
        arima_predicted_data=arima_predicted_data,
        scaler=scaler,
        scaling=scaling_flag,
    )

    # Retransform predictions
    predictions_retransformed = retransform_predictions(
        aggregated_predictions=predictions_aggregated,
        processed_master_data=master_data_processed,
        generic_flag=generic_flag,
    )

    return predictions_retransformed


def forecast_asp(
    master_data_processed,
    market_event_data_processed,
    config_dict,
    test_months,
    generic_flag,
    train_quarters,
):
    print("Training arima..")
    # Step 1: Train ARIMA model and predict forecast
    arima_predicted_data = train_and_predict_with_arima(
        processed_master_data=master_data_processed,
        forecast_months=config_dict["forecast_months"],
        target_variable=config_dict["target_variable"],
        time_series_columns=config_dict["time_series_columns"],
    )
    print("Trained arima and predicted the forecast succesfully!")

    print("Getting residuals and other exogenous features ready for step-2..")

    # Step 2: Prepare static and market event features for XGBoost
    static_feature_data = get_static_features(
        processed_master_data=master_data_processed,
        generic_flag=generic_flag,
        forecast_months=config_dict["forecast_months"],
        static_columns=config_dict["static_columns"],
    )

    scaler_obj, transformed_data_scaled, transformed_data_unscaled = transform_data(
        predicted_arima_forecast=arima_predicted_data,
        time_series_columns=config_dict["time_series_columns"],
        test_months=test_months,
    )

    if generic_flag:
        market_event_feature_data = get_market_event_features_for_generic(
            processed_master_data=master_data_processed,
            time_cap=config_dict["time_cap"],
        )
    else:
        market_event_feature_data = pd.DataFrame()
        static_feature_data = update_event_features_for_non_generic(
            static_feature_data=static_feature_data,
            market_event_data=market_event_data_processed,
            train_data_end_quarter=max(train_quarters),
        )

    print("The Data is ready to be trained! ")

    print("Training xg-boost to forecast the residuals..")

    # Step 3: Train XGBoost to forecast residuals
    predictions_scaled = train_and_predict_residuals_xgb(
        transformed_data=transformed_data_scaled,
        market_event_feature_data=market_event_feature_data,
        static_feature_data=static_feature_data,
        master_data_processed=master_data_processed,
        arima_predicted_data=arima_predicted_data,
        config_dict=config_dict,
        generic_flag=generic_flag,
        test_months=test_months,
        scaler=scaler_obj,
        scaling_flag=True,
    )
    predictions_unscaled = train_and_predict_residuals_xgb(
        transformed_data=transformed_data_unscaled,
        market_event_feature_data=market_event_feature_data,
        static_feature_data=static_feature_data,
        master_data_processed=master_data_processed,
        arima_predicted_data=arima_predicted_data,
        config_dict=config_dict,
        generic_flag=generic_flag,
        test_months=test_months,
        scaler=None,
        scaling_flag=False,
    )

    # Step 4: Combine scaled and unscaled predictions
    predictions_scaled = predictions_scaled[
        ["J_CODE", "Time", "ASP_forecasted_mean"]
    ].rename(columns={"ASP_forecasted_mean": "ASP_pred_scaled", "Time": "Quarter"})
    predictions_unscaled = predictions_unscaled[
        ["J_CODE", "Time", "ASP_forecasted_mean"]
    ].rename(columns={"ASP_forecasted_mean": "ASP_pred_unscaled", "Time": "Quarter"})

    predictions = pd.merge(
        predictions_unscaled, predictions_scaled, how="inner", on=["J_CODE", "Quarter"]
    )
    return predictions
