# ASP Forecasting 
- In collaboration with MT DDI Data Science, ZS, PSaS Decision Intelligence (August 2023)
- Business Stakeholder: Provider Solutions (PSaS) Decision Intelligence

## Background
![Screenshot 2024-01-31 at 9 42 51 AM](https://github.com/mckesson/asp-forecasting/assets/8948604/ef792804-b3f4-4a95-a1f6-e48e21d50bc3)
![Screenshot 2024-01-31 at 9 43 12 AM](https://github.com/mckesson/asp-forecasting/assets/8948604/f71eacce-60db-4f65-811a-74e17dfb75ad)
![Screenshot 2024-01-31 at 9 54 14 AM](https://github.com/mckesson/asp-forecasting/assets/8948604/72c87957-bf53-4745-9f2f-9ff6fcef616a)
![Screenshot 2024-01-31 at 9 55 03 AM](https://github.com/mckesson/asp-forecasting/assets/8948604/3d427a15-fbc0-48fa-9814-e21f0bbfeb4c)

## Install Requirements
Ensure you have Python 3.8+ installed. You can install the dependencies listed in requirements.txt by running the following:

`pip install -r requirements.txt`

If you are running this script in **All Purpose cluster**, please add below code as first line to your **main.py** script to install dependencies.

`!pip install -r requirements.txt`

## Databricks Infrastructure details
#### DEV Environment
- Resource Group - rg-psas-decision-intelligence-westus-dev
- AD Group Name - azure-psas-di-dataengineer-dev
- Workspace Name - dbw-psasdi-dev-01
- Development Cluster - DEV_PSASDI_Lakehouse_Shared_Standard_Cluster_01
- Deployment cluster - Job cluster (see below to know more on cluster configs)
- Service Principal used for Job - SP_PSAS_DI

#### QAT Environment
- Resource Group - rg-psas-decision-intelligence-westus-qat
- AD Group Name - azure-psas-di-dataengineer-qa
- Workspace Name - dbw-psasdi-qat-01
- Development Cluster - Not Applicable
- Deployment cluster - Job clusters (see below section to know more)
- Service Principal used for Job - SP_PSAS_DI

#### PROD Environment
- Resource Group - rg-psas-decision-intelligence-westus-prod
- AD Group Name - 	azure-psas-di-dataengineer-prod
- Workspace Name - dbw-psasdi-prod-01
- Deployment cluster - Job clusters (see below section to know more)
- Service Principal used for Job - **TBA**

## Cluster Details
### Job Cluster Details
The pipelines were developed and tested in **All purpose compute** with below specifications
```
{
    "cluster_id": "0711-110246-8tss22xh",
    "driver": {
        "private_ip": "10.181.32.12",
        "node_id": "896635e2df5a4b22b8c35151b09e3e54",
        "instance_id": "216a0514c5fd4cbe91375e48bdcbb802",
        "start_timestamp": 1728027811099,
        "node_attributes": {
            "is_spot": false
        },
        "host_private_ip": "10.181.48.11"
    },
    "executors": [
        {
            "private_ip": "10.181.32.11",
            "public_dns": "",
            "node_id": "84377a9b9cf44ef4ae53494c643d4a4c",
            "instance_id": "9acd6557388b4f8cb1fbe2f0743ad436",
            "start_timestamp": 1728027811011,
            "node_attributes": {
                "is_spot": true
            },
            "host_private_ip": "10.181.48.10"
        },
        {
            "private_ip": "10.181.32.10",
            "public_dns": "",
            "node_id": "dda264a22917439094d9c97e5146f414",
            "instance_id": "00b1fc0d15b84d9aa671a0ff3b42b08f",
            "start_timestamp": 1728027811055,
            "node_attributes": {
                "is_spot": true
            },
            "host_private_ip": "10.181.48.12"
        }
    ],
    "spark_context_id": 7643106485820957000,
    "driver_healthy": true,
    "jdbc_port": 10000,
    "cluster_name": "DEV_EDP_PSAS_DI_S_UC_03",
    "spark_version": "13.3.x-scala2.12",
    "spark_conf": {
        "spark.databricks.delta.preview.enabled": "true",
        "spark.databricks.sql.initial.catalog.name": "psas_di_dev"
    },
    "azure_attributes": {
        "first_on_demand": 1,
        "availability": "SPOT_WITH_FALLBACK_AZURE",
        "spot_bid_max_price": -1
    },
    "node_type_id": "Standard_E16_v3",
    "driver_node_type_id": "Standard_E16_v3",
    "custom_tags": {
        "business-unit": "PSAS",
        "x_core-application-name": "psas-di-common",
        "x_core-env": "dev",
        "x_core-tech-owner": "arjun.saladi@mckesson.com"
    },
    "cluster_log_conf": {
        "dbfs": {
            "destination": "dbfs:/cluster-logs"
        }
    },
    "autotermination_minutes": 20,
    "enable_elastic_disk": true,
    "disk_spec": {},
    "cluster_source": "UI",
    "policy_id": "D064420D2F001358",
    "enable_local_disk_encryption": false,
    "instance_source": {
        "node_type_id": "Standard_E16_v3"
    },
    "driver_instance_source": {
        "node_type_id": "Standard_E16_v3"
    },
    "data_security_mode": "USER_ISOLATION",
    "runtime_engine": "STANDARD",
    "effective_spark_version": "13.3.x-scala2.12",
    "autoscale": {
        "min_workers": 2,
        "max_workers": 4,
        "target_workers": 2
    },
    "cluster_memory_mb": 393216,
    "cluster_cores": 48,
    "cluster_log_status": {
        "last_attempted": 1728029142795
    },
    "init_scripts_safe_mode": false,
    "spec": {
        "cluster_name": "DEV_EDP_PSAS_DI_S_UC_03",
        "spark_version": "13.3.x-scala2.12",
        "spark_conf": {
            "spark.databricks.delta.preview.enabled": "true",
            "spark.databricks.sql.initial.catalog.name": "psas_di_dev"
        },
        "azure_attributes": {
            "first_on_demand": 1,
            "availability": "SPOT_WITH_FALLBACK_AZURE",
            "spot_bid_max_price": -1
        },
        "node_type_id": "Standard_E16_v3",
        "driver_node_type_id": "Standard_E16_v3",
        "cluster_log_conf": {
            "dbfs": {
                "destination": "dbfs:/cluster-logs"
            }
        },
        "autotermination_minutes": 20,
        "enable_elastic_disk": true,
        "policy_id": "D064420D2F001358",
        "enable_local_disk_encryption": false,
        "data_security_mode": "USER_ISOLATION",
        "runtime_engine": "STANDARD",
        "autoscale": {
            "min_workers": 2,
            "max_workers": 4
        },
        "apply_policy_default_values": false
    }
}
```

The pipelines were tested using **job clusters** with below configurations

```
{
    "autoscale": {
        "min_workers": 2,
        "max_workers": 4
    },
    "cluster_name": "",
    "spark_version": "14.1.x-scala2.12",
    "spark_conf": {},
    "azure_attributes": {
        "first_on_demand": 1,
        "availability": "SPOT_WITH_FALLBACK_AZURE",
        "spot_bid_max_price": -1
    },
    "node_type_id": "Standard_E16_v3",
    "ssh_public_keys": [],
    "custom_tags": {
        "USECASE": "ASP-FORECAST",
        "ENV": "DEV"
    },
    "spark_env_vars": {},
    "enable_elastic_disk": true,
    "init_scripts": [],
    "data_security_mode": "SINGLE_USER",
    "runtime_engine": "PHOTON"
}
```

## Generate ASP Forecast

### Overview:
This pipeline has been designed to generate a quarterly ASP (Average Selling Price) forecast for the subsequent 8 quarters for a set of Medicare part-B Products.

### Input:

1. **Historical ASP data**
    - The historical ASPdata (payment limit) for each J-Code, will be acquired from the [CMS website](https://www.cms.gov/medicare/payment/all-fee-service-providers/medicare-part-b-drug-average-sales-price/asp-pricing-files) and consolidated into the necessary format as outlined in the data processing documentation.

2. **Market event data** 
    - This dataset comprises third-party data sourced from the [Evaluate Pharma portal](https://www.evaluate.com/products-services/pharma/evaluate-pharma), providing insights into product launches, loss of   
        exclusivity, and indicator expansion, thus offering a comprehensive overview of the broader market dynamics landscape.

3. **Product characteristics** 
    - Product characteristics include features such as therapeutic category, disease state, etc.

### Output:
ASP forecast for selected products for subsequent 8 quarters

To know more about the pipeline operations please refer to this [confluence](https://mckesson.atlassian.net/wiki/spaces/~638813e900cb2fc3f98a7e81/pages/87348282441/ASP+-+Data+Science+ML+Ops) page

### Process Flow Diagram

#### Training Pipeline
To know process flow for the training pipeline, please refer to this [section](https://mckesson.atlassian.net/wiki/spaces/~638813e900cb2fc3f98a7e81/pages/87348282441/ASP+-+Data+Science+ML+Ops#Data-Flow-Diagram)

#### Inference Pipeline
To know process flow for the inference pipeline, please refer to this [section](https://mckesson.atlassian.net/wiki/spaces/~638813e900cb2fc3f98a7e81/pages/87348282441/ASP+-+Data+Science+ML+Ops#Data-Flow-Diagram.1) 

### How to run the code from terminal CL
#### Pre-requisites
1. Setting up Git Integration to your databricks workspace
2. Clone repository in azure databricks
Please follow this step by step [guide](https://learn.microsoft.com/en-us/azure/databricks/repos/repos-setup)
3. Make sure you have access to AD Groups, and workspace(refered in Infrastructure details section) to access the data stored in the catalog.

#### Step by step process to run this code in notebook/Script
- Go to **main.py**
- Go to **config.yaml**, set the paths pointing to your workspace location
- Click on **Run** to run the script

### How to run the code as Workflows
#### Pre-requisites
1. Setting up Git Integration to your databricks workspace
2. To Clone repository in azure databricks please follow this step by step [guide](https://learn.microsoft.com/en-us/azure/databricks/repos/repos-setup)

#### Step by step process to create databricks job
- Go to **Workflows**, and click on create **Create Job**
- Configure the Job
    - Name: Provide meaningfull name to the job
    - Task: Setup the task for the job. This will be typically the Python Script
    - Source: Setup the source as **Workspace**
    - Path:Set the path located to your cloned repository
    - Cluster: Choose an existing cluster (or) create new one
- Dependent Libraries: Mention libraries in requirements.txt file
- Parameters: Set Job parameters. Please make sure you have access to this mentioned catalog, and workspace
     - For **Training Pipeline** - ["catalog_name:edp_psas_di_qat","storage_account:stpsasdicore52"]. 
     - For **Inferene Pipeline** - ["catalog_name:edp_psas_di_qat","storage_account:stpsasdicore52"].
- Schedule the job if you want to run it on regular intervals

## Test Suite

Following test suite are added to this project to check code reliability. Please refer to this [confluence](https://mckesson.atlassian.net/wiki/spaces/~638813e900cb2fc3f98a7e81/pages/87348282441/ASP+-+Data+Science+ML+Ops#Unit-Testing) page for model details

## Conclusion

To know more about this project, please refer to this [confluence](https://mckesson.atlassian.net/wiki/spaces/~638813e900cb2fc3f98a7e81/pages/87348282441/ASP+-+Data+Science+ML+Ops) page
