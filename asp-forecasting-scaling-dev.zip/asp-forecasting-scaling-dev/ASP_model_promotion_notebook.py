# Databricks notebook source
# MAGIC %md
# MAGIC ### Description
# MAGIC This notebook purpose is to promote mentioned version number as champion for our production "INFERENCE" champion pipeline. To view current registered models, please view in the Models section  in unity catalog. 
# MAGIC
# MAGIC - **Unity catalog Name**: edp_psas_di_prd
# MAGIC - **Models** : generic-scaled, generic-unscaled, nongeneric-scaled, nongeneric-unscaled
# MAGIC
# MAGIC **NOTE:**
# MAGIC 1. Model Promotion can also be possible when run with Service Principal
# MAGIC 2. Always add alias_name = 'champion' for the champion model.
# MAGIC 3. Update the catalog_name and version_number only from below notebook
# MAGIC

# COMMAND ----------

# **1. Import necessary libraries**
# If this cell throws error, please connect to following POC's
# Saisrinivas.Putta@McKesson.com, Madhivarman.Ar@McKesson.com, Ying.Pei@McKesson.com
 
%pip install mlflow[databricks]
import mlflow
from mlflow import MlflowClient

# Set mlflow registry URI to Databricks
mlflow.set_registry_uri("databricks-uc")

# Set up mlflow client
client = MlflowClient()

# Mention the catalog name
"""
For QAT environment, catalog_name = 'edp_psas_di_qat'
For PROD environment, catalog_name = 'edp_psas_di_prd'
"""
catalog_name = 'edp_psas_di_qat' # should change the name to PROD environment

model_name = [
    f"{catalog_name}.edp_psas_di_usp_gold.generic-scaled",
    f"{catalog_name}.edp_psas_di_usp_gold.generic-unscaled",
    f"{catalog_name}.edp_psas_di_usp_gold.nongeneric-scaled",
    f"{catalog_name}.edp_psas_di_usp_gold.nongeneric-unscaled"
]

# Mention the version number and respective alias
"""
Example 1: If version 16 needs to be champion then pass
version_number = 16 and alias_name = 'champion'.

Example 2: If version 17 needs to be champion then pass
version_number = 17 and alias_name = 'champion'.
"""
version_number = 17 # set the desired version number you want to promote as champion
alias_name = 'challenger' # do not change this tag, keep as it is

# pass the list of models from model_name list and set alias as per above config.
for model in model_name:
    client.set_registered_model_alias(model,alias_name,version_number)
